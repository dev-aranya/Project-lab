 async function showTable(type) {
      const tableContainer = document.getElementById("tableContainer");
      tableContainer.innerHTML = `<p>Loading ${type}...</p>`;

      try {
        const response = await fetch(`http://localhost:3000/${type}`);
        const data = await response.json();

        if (!Array.isArray(data) || data.length === 0) {
          tableContainer.innerHTML = `<p class="no-data">No ${type} data found.</p>`;
          return;
        }

        let headers = Object.keys(data[0]);
        let tableHTML = `
          <table id="${type}Table">
            <thead>
              <tr>${headers.map(h => `<th>${h.replace(/_/g, " ")}</th>`).join("")}</tr>
            </thead>
            <tbody>
              ${data.map(row =>
                `<tr>${headers.map(h => `<td>${row[h] ?? '-'}</td>`).join("")}</tr>`
              ).join("")}
            </tbody>
          </table>
        `;

        tableContainer.innerHTML = tableHTML;
        document.getElementById(`${type}Table`).style.display = "table";

      } catch (err) {
        console.error("Error fetching data:", err);
        tableContainer.innerHTML = `<p class="no-data">Error loading ${type} data.</p>`;
      }
    }