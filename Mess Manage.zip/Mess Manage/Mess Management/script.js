// Switch between sections
function showTable(sectionId) {
  // Hide all sections
  document.querySelectorAll(".table-section").forEach(sec => sec.classList.remove("active"));
  // Remove active class from buttons
  document.querySelectorAll("nav button").forEach(btn => btn.classList.remove("active"));
  // Show selected
  document.getElementById(sectionId).classList.add("active");
  event.target.classList.add("active");

  // If students selected — load data
  if (sectionId === "students") {
    loadStudents();
  }
}

// Fetch student data
async function loadStudents() {
  const container = document.getElementById("tableContainer");
  container.innerHTML = `<p class="loading">Loading students...</p>`;

  try {
    const res = await fetch("http://localhost:3000/students");
    const data = await res.json();

    if (!Array.isArray(data) || data.length === 0) {
      container.innerHTML = `<p class="no-data">No students found.</p>`;
      return;
    }

    let tableHTML = `
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Class</th>
            <th>Roll No</th>
            <th>Contact</th>
            <th>Address</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          ${data.map(stu => `
            <tr>
              <td>${stu.student_id}</td>
              <td>${stu.student_name}</td>
              <td>${stu.class || '-'}</td>
              <td>${stu.roll_no || '-'}</td>
              <td>${stu.contact || '-'}</td>
              <td>${stu.address || '-'}</td>
              <td>
                <button class="delete-btn" onclick="deleteStudent(${stu.student_id})">Delete</button>
              </td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;
    container.innerHTML = tableHTML;
  } catch (err) {
    console.error(err);
    container.innerHTML = `<p class="no-data">Error loading students.</p>`;
  }
}

// Delete student function
async function deleteStudent(studentId) {
  if (!confirm("Are you sure you want to delete this student?")) return;

  try {
    const res = await fetch(`http://localhost:3000/students/${studentId}`, {
      method: "DELETE"  // <-- THIS IS IMPORTANT
    });

    const data = await res.json();

    if (res.ok) {
      alert(data.message);
      loadStudents(); // refresh table
    } else {
      alert(data.error || "Error deleting student");
    }
  } catch (err) {
    console.error(err);
    alert("Error deleting student");
  }
}


// add student
// Show Add Student form
function showAddStudent() {
  document.querySelectorAll(".table-section").forEach(sec => sec.classList.remove("active"));
  document.getElementById("addStudent").classList.add("active");
}

// Handle student form submission
const studentForm = document.getElementById("studentForm");
const formMessage = document.getElementById("formMessage");

studentForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const studentData = {
    student_name: document.getElementById("student_name").value,
    class: document.getElementById("class").value,
    roll_no: document.getElementById("roll_no").value,
    contact: document.getElementById("contact").value,
    address: document.getElementById("address").value,
  };

  try {
    const res = await fetch("http://localhost:3000/students", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(studentData),
    });

    const data = await res.json();

    if (res.ok) {
      formMessage.textContent = `✅ ${data.message} (ID: ${data.student_id})`;
      formMessage.className = "form-message success";
      studentForm.reset();
    } else {
      formMessage.textContent = `❌ ${data.error}`;
      formMessage.className = "form-message error";
    }
  } catch (err) {
    console.error(err);
    formMessage.textContent = "❌ Error submitting form";
    formMessage.className = "form-message error";
  }
});

