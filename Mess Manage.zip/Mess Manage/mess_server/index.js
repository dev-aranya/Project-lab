// -------------------- IMPORTS --------------------
import express from "express";
import cors from "cors";
import mysql from "mysql2/promise"; // Promise-based MySQL

// -------------------- CONFIG --------------------
const app = express();
app.use(cors());
app.use(express.json());

// -------------------- MYSQL CONNECTION (POOL) --------------------
const db = await mysql.createPool({
  host: "localhost",             // your MySQL host
  user: "meal_user",                  // your MySQL username
  password: "meal_password",               // your MySQL password
  database: "school_meal_management", // your database name
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  connectTimeout: 10000,
});

console.log("✅ Connected to MySQL database (pool ready)");

// -------------------- ROUTES --------------------

// Root route
app.get("/", (req, res) => {
  res.send("🍽️ Meal Management API is running...");
});

// -------------------- STUDENTS --------------------

// Get all students
app.get("/students", async (req, res) => {
  try {
    const [results] = await db.query("SELECT * FROM Students");
    res.json(results);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add a student
app.post("/students", async (req, res) => {
  const { student_name, class: className, roll_no, contact, address } = req.body;
  try {
    const sql = `
      INSERT INTO Students (student_name, class, roll_no, contact, address)
      VALUES (?, ?, ?, ?, ?)
    `;
    const [result] = await db.query(sql, [student_name, className, roll_no, contact, address]);
    res.json({ message: "Student added successfully!", student_id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete student (also deletes related meals)
app.delete("/students/:id", async (req, res) => {
  const studentId = req.params.id;
  try {
    await db.query("DELETE FROM Meals WHERE student_id = ?", [studentId]); // Delete meals first
    const [result] = await db.query("DELETE FROM Students WHERE student_id = ?", [studentId]);

    if (result.affectedRows === 0)
      return res.status(404).json({ error: "Student not found" });

    res.json({ message: "Student deleted successfully (related meals deleted too)" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// -------------------- FOOD ITEMS --------------------

// Get all food items
app.get("/fooditems", async (req, res) => {
  try {
    const [results] = await db.query("SELECT * FROM FoodItems");
    res.json(results);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add a food item
app.post("/fooditems", async (req, res) => {
  const { food_name, unit_price } = req.body;
  try {
    const [result] = await db.query(
      "INSERT INTO FoodItems (food_name, unit_price) VALUES (?, ?)",
      [food_name, unit_price]
    );
    res.json({ message: "Food item added successfully!", food_id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// -------------------- MEALS --------------------

// Get all meals
app.get("/meals", async (req, res) => {
  try {
    const sql = `
      SELECT m.meal_id, m.student_id, m.food_id, s.student_name, f.food_name, m.meal_date, m.quantity, m.total_cost
      FROM meals m
      JOIN Students s ON m.student_id = s.student_id
      JOIN FoodItems f ON m.food_id = f.food_id
      ORDER BY m.meal_date DESC
    `;
    const [results] = await db.query(sql);
    res.json(results);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add a meal (auto-calculate total cost)
app.post("/meals", async (req, res) => {
  const { student_id, food_id, meal_date, quantity } = req.body;
  console.log("Adding meal:", req.body);  // Debug
  try {
    const [food] = await db.query("SELECT unit_price FROM FoodItems WHERE food_id = ?", [food_id]);
    if (food.length === 0) return res.status(404).json({ error: "Food item not found" });

    const total_cost = food[0].unit_price * quantity;
    const sql = "INSERT INTO meals (student_id, food_id, meal_date, quantity, total_cost) VALUES (?, ?, ?, ?, ?)";
    const [result] = await db.query(sql, [student_id, food_id, meal_date, quantity, total_cost]);

    console.log("Inserted meal:", result);
    res.json({ message: "Meal added successfully!", meal_id: result.insertId, total_cost });
  } catch (err) {
    console.error("Meal insert error:", err);  // Debug
    res.status(500).json({ error: err.message });
  }
});


// Update a meal
app.put("/meals/:id", async (req, res) => {
  const mealId = req.params.id;
  const { student_id, food_id, meal_date, quantity } = req.body;
  try {
    const [food] = await db.query("SELECT unit_price FROM FoodItems WHERE food_id = ?", [food_id]);
    if (food.length === 0) return res.status(404).json({ error: "Food item not found" });

    const total_cost = food[0].unit_price * quantity;
    const sql = `
      UPDATE Meals
      SET student_id = ?, food_id = ?, meal_date = ?, quantity = ?, total_cost = ?
      WHERE meal_id = ?
    `;
    const [result] = await db.query(sql, [student_id, food_id, meal_date, quantity, total_cost, mealId]);

    if (result.affectedRows === 0) return res.status(404).json({ error: "Meal not found" });

    res.json({ message: "Meal updated successfully!", total_cost });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete a meal
app.delete("/meals/:id", async (req, res) => {
  const mealId = req.params.id;
  try {
    const [result] = await db.query("DELETE FROM meals WHERE meal_id = ?", [mealId]);
    if (result.affectedRows === 0) return res.status(404).json({ error: "Meal not found" });

    res.json({ message: "Meal deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// -------------------- BAZAR BILLS --------------------

// Get all bazar bills
app.get("/bazarbills", async (req, res) => {
  try {
    const [results] = await db.query("SELECT * FROM BazarBills ORDER BY bill_date DESC");
    res.json(results);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add a bazar bill
app.post("/bazarbills", async (req, res) => {
  const { bill_date, description, total_amount } = req.body;
  try {
    const [result] = await db.query(
      "INSERT INTO BazarBills (bill_date, description, total_amount) VALUES (?, ?, ?)",
      [bill_date, description, total_amount]
    );
    res.json({ message: "Bazar bill added successfully!", bill_id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});








app.get("/bills", async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT b.bill_id, s.student_name, b.total_meals, b.total_amount, 
             b.bill_month, b.status, b.generated_date
      FROM StudentBills b
      JOIN Students s ON b.student_id = s.student_id
      ORDER BY b.generated_date DESC
    `);
    res.json(rows);
  } catch (err) {
    console.error("Error fetching bills:", err);
    res.status(500).json({ error: err.message });
  }
});

// -------------------- ADD a new bill --------------------
app.post("/bills", async (req, res) => {
  const { student_id, total_meals, total_amount, bill_month, status, generated_date } = req.body;

  if (!student_id || !total_meals || !total_amount || !bill_month || !status) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  try {
    const [result] = await db.query(
      `INSERT INTO StudentBills (student_id, total_meals, total_amount, bill_month, status, generated_date)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [student_id, total_meals, total_amount, bill_month, status, generated_date || new Date()]
    );

    res.json({ message: "Bill added successfully!", bill_id: result.insertId });
  } catch (err) {
    console.error("Error adding bill:", err);
    res.status(500).json({ error: err.message });
  }
});

// -------------------- DELETE a bill --------------------
app.delete("/bills/:id", async (req, res) => {
  try {
    const [result] = await db.query("DELETE FROM StudentBills WHERE bill_id = ?", [req.params.id]);

    if (result.affectedRows === 0)
      return res.status(404).json({ error: "Bill not found" });

    res.json({ message: "Bill deleted successfully!" });
  } catch (err) {
    console.error("Error deleting bill:", err);
    res.status(500).json({ error: err.message });
  }
});





// -------------------- REGISTER --------------------
app.post("/register", async (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password)
    return res.json({ success: false, error: "All fields required" });

  const hashedPass = await bcrypt.hash(password, 10);

  try {
    await db.query(
      "INSERT INTO users (name, email) VALUES (?, ?)",
      [name, email]
    );
    res.json({ success: true, message: "Registration successful" });
  } catch (e) {
    res.json({ success: false, error: "Email already exists" });
  }
});

/* =======================================================
    ✅ LOGIN API
=========================================================*/
app.post("/login", async (req, res) => {
  const { email, password } = req.body;

  const [rows] = await db.query("SELECT * FROM users WHERE email = ?", [email]);

  if (!rows.length)
    return res.json({ success: false, error: "User not found" });

  const user = rows[0];

 

  if (!match)
    return res.json({ success: false, error: "Incorrect password" });

  // No JWT, just respond with user info
  res.json({
    success: true,
    message: "Login successful",
    name: user.name,
    email: user.email,
    id: user.id
  });
});

// -------------------- START SERVER --------------------
const PORT = 3000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
