// Complete destination data with food, history, and attractions
const destinationsData = {
    "times-square-new-york": {
        id: "times-square-new-york",
        name: "Times Square, New York",
        image: "New_york.jpg",
        tagline: "The Dazzling 'Crossroads of the World' that never sleeps",
        location: "Manhattan, New York City, NY, USA",
        description: "Times Square is a major commercial intersection, tourist destination, entertainment hub, and neighborhood in Midtown Manhattan, New York City. Brightly lit by numerous billboards and advertisements, it stretches from West 42nd to West 47th Streets and is the heart of the Broadway Theater District.",
        
        history: {
            title: "A Rich History",
            content: "Originally named Longacre Square, Times Square was renamed in 1904 after The New York Times moved its headquarters to the newly erected Times Building. The famous New Year's Eve ball drop tradition began in 1907 and has become an iconic global celebration. During the early 20th century, Times Square became the cultural hub of New York, hosting theaters, hotels, and restaurants. Despite challenges during the 1960s-1980s, a major revitalization effort in the 1990s transformed it into the family-friendly tourist destination it is today."
        },
        
        cuisine: {
            title: "Must-Try Foods",
            dishes: [
                {
                    name: "New York-Style Pizza",
                    description: "Thin, wide slices with a crispy crust - grab a slice from iconic pizzerias like Joe's Pizza or Artichoke Basille's."
                },
                {
                    name: "Hot Dogs from Street Vendors",
                    description: "Classic NYC street food experience with a Nathan's Famous hot dog from vendors around Times Square."
                },
                {
                    name: "Bagels & Lox",
                    description: "Fresh bagels with smoked salmon, cream cheese, capers, and onions from nearby delis."
                },
                {
                    name: "Cheesecake",
                    description: "World-famous New York cheesecake from Junior's or other local bakeries."
                }
            ]
        },
        
        attractions: [
            "Broadway Shows & Theater District",
            "New Year's Eve Ball Drop Location",
            "Madame Tussauds Wax Museum",
            "Ripley's Believe It or Not!",
            "M&M's World Store",
            "TKTS Discount Booth for Broadway tickets",
            "Hard Rock Cafe Times Square",
            "Paramount Building & Historic Architecture"
        ],
        
        tips: [
            "Visit early morning (6-8 AM) for photos without crowds",
            "Get discounted Broadway tickets at TKTS booth",
            "Most attractions are free to view from the street",
            "Use NYC subway to avoid traffic - Times Square station serves multiple lines",
            "Book restaurants in advance during peak season"
        ]
    },

    "national-mall-washington": {
        id: "national-mall-washington",
        name: "National Mall & Memorial Park, Washington D.C.",
        image: "Mall-011.jpg",
        tagline: "A timeless symbol of history and freedom",
        location: "Washington, D.C., USA",
        description: "The National Mall is America's most visited national park, stretching over 2 miles from the U.S. Capitol to the Lincoln Memorial. This iconic green expanse is lined with monuments, memorials, and museums that tell the story of American democracy, sacrifice, and achievement.",
        
        history: {
            title: "Historic Significance",
            content: "Designed by Pierre L'Enfant in 1791 as part of the nation's capital plan, the Mall has been the site of numerous pivotal moments in American history. From Martin Luther King Jr.'s 'I Have a Dream' speech in 1963 to presidential inaugurations, the Mall serves as the nation's premier civic space. The monuments honor presidents, war veterans, and civil rights leaders, creating a living testament to American values and struggles."
        },
        
        cuisine: {
            title: "Local Flavors",
            dishes: [
                {
                    name: "Half-Smoke Hot Dog",
                    description: "DC's signature sausage - a spicy smoked sausage link, bigger than a hot dog, often served with chili and onions. Try Ben's Chili Bowl."
                },
                {
                    name: "Mumbo Sauce",
                    description: "A sweet and tangy sauce unique to DC, served over chicken wings and fried rice at carryouts."
                },
                {
                    name: "Chesapeake Blue Crabs",
                    description: "Fresh steamed blue crabs with Old Bay seasoning from the nearby Chesapeake Bay."
                },
                {
                    name: "Ethiopian Cuisine",
                    description: "DC has a vibrant Ethiopian community - try injera bread with various stews and dishes."
                }
            ]
        },
        
        attractions: [
            "Lincoln Memorial",
            "Washington Monument",
            "U.S. Capitol Building",
            "Smithsonian Museums (Air & Space, Natural History, American History)",
            "Vietnam Veterans Memorial",
            "World War II Memorial",
            "Martin Luther King Jr. Memorial",
            "Jefferson Memorial & Tidal Basin"
        ],
        
        tips: [
            "All Smithsonian museums are FREE admission",
            "Visit during cherry blossom season (late March/early April)",
            "Wear comfortable walking shoes - the Mall is huge",
            "Start early to beat crowds and heat in summer",
            "Most monuments are open 24/7 and beautifully lit at night"
        ]
    },

    "disney-world-florida": {
        id: "disney-world-florida",
        name: "Disney World's Magic Kingdom, Florida",
        image: "magic-kingdom.jpg",
        tagline: "Where childhood dreams come alive",
        location: "Bay Lake and Lake Buena Vista, Florida, USA",
        description: "Magic Kingdom is the most visited theme park in the world, welcoming over 20 million guests annually. This enchanted kingdom features iconic Cinderella Castle, classic Disney attractions, beloved characters, and nightly fireworks that illuminate childhood dreams. It's divided into six themed lands, each offering unique experiences and adventures.",
        
        history: {
            title: "The Dream That Started It All",
            content: "Opening on October 1, 1971, Magic Kingdom was the first theme park built at Walt Disney World Resort. Walt Disney envisioned a place where parents and children could have fun together. Though Walt passed away before its completion, his brother Roy Disney saw the dream realized. The park's iconic Cinderella Castle stands at 189 feet tall and serves as the symbol of Disney magic worldwide. Over five decades, it has evolved while maintaining Walt's original vision of immersive storytelling and family entertainment."
        },
        
        cuisine: {
            title: "Magical Dining",
            dishes: [
                {
                    name: "Dole Whip",
                    description: "Legendary pineapple soft-serve treat from Aloha Isle in Adventureland - a must-have Disney snack."
                },
                {
                    name: "Mickey-Shaped Treats",
                    description: "Everything from Mickey waffles at breakfast to Mickey pretzels, ice cream bars, and beignets throughout the park."
                },
                {
                    name: "Turkey Legs",
                    description: "Giant smoked turkey legs - a Disney Parks favorite for hungry adventurers."
                },
                {
                    name: "Cinderella's Royal Table",
                    description: "Fine dining inside Cinderella Castle with appearances by Disney Princesses."
                }
            ]
        },
        
        attractions: [
            "Cinderella Castle & Happily Ever After Fireworks",
            "Space Mountain (Tomorrowland)",
            "Pirates of the Caribbean (Adventureland)",
            "Haunted Mansion (Liberty Square)",
            "Big Thunder Mountain Railroad (Frontierland)",
            "Seven Dwarfs Mine Train (Fantasyland)",
            "Splash Mountain (Frontierland)",
            "Character Meet & Greets throughout the park"
        ],
        
        tips: [
            "Arrive 30 minutes before park opening",
            "Use Disney Genie+ to skip lines on popular attractions",
            "Stay for evening fireworks - Happily Ever After is spectacular",
            "Visit during off-peak seasons (January, September) for shorter waits",
            "Book dining reservations 60 days in advance"
        ]
    },

    "trafalgar-square-london": {
        id: "trafalgar-square-london",
        name: "Trafalgar Square, London",
        image: "trafalgar.png",
        tagline: "The cultural heart of London",
        location: "Westminster, Central London, UK",
        description: "Trafalgar Square is one of London's most famous public spaces, built to commemorate Lord Nelson's victory at the Battle of Trafalgar. The square features Nelson's Column, magnificent fountains, bronze lion statues, and the National Gallery. It's a gathering place for celebrations, protests, and cultural events.",
        
        history: {
            title: "Monument to Naval Victory",
            content: "Built in 1840-1845, Trafalgar Square honors Admiral Lord Nelson's 1805 naval victory against Napoleon's fleet. Nelson's Column stands 169 feet tall, topped with a 17-foot statue of the admiral. The four bronze lions, added in 1867, were sculpted by Sir Edwin Landseer. The square has witnessed countless historic moments, from VE Day celebrations to New Year's festivities, and remains central to British public life and national celebrations."
        },
        
        cuisine: {
            title: "British Classics",
            dishes: [
                {
                    name: "Fish and Chips",
                    description: "Britain's most famous dish - battered cod or haddock with chunky chips, best from nearby traditional pubs."
                },
                {
                    name: "Afternoon Tea",
                    description: "Elegant tea service with finger sandwiches, scones with clotted cream and jam, and pastries at nearby hotels."
                },
                {
                    name: "Pie and Mash",
                    description: "Traditional London working-class meal - meat pie served with mashed potatoes and parsley liquor sauce."
                },
                {
                    name: "Full English Breakfast",
                    description: "Hearty morning meal with eggs, bacon, sausages, beans, mushrooms, tomatoes, and toast."
                }
            ]
        },
        
        attractions: [
            "Nelson's Column & The Four Lions",
            "The National Gallery (free admission)",
            "National Portrait Gallery",
            "St Martin-in-the-Fields Church",
            "Canada House & South Africa House",
            "The Fourth Plinth (rotating contemporary art)",
            "Admiralty Arch gateway to The Mall",
            "Nearby Covent Garden & Leicester Square"
        ],
        
        tips: [
            "The National Gallery is free - allow 2-3 hours to explore",
            "Visit during Christmas for the giant Christmas tree (gift from Norway)",
            "Watch free lunchtime concerts at St Martin-in-the-Fields",
            "The square is best photographed from the National Gallery steps",
            "Use the Charing Cross tube station - closest to the square"
        ]
    },

    "maldives": {
        id: "maldives",
        name: "Maldives",
        image: "maldives.jpg",
        tagline: "A true paradise on Earth",
        location: "Indian Ocean, Southwest of India and Sri Lanka",
        description: "The Maldives is a tropical paradise consisting of 1,190 coral islands grouped into 26 atolls. Known for crystal-clear turquoise waters, pristine white sand beaches, vibrant coral reefs, and luxurious overwater bungalows, it's one of the world's most exclusive and beautiful destinations.",
        
        history: {
            title: "Island Nation Heritage",
            content: "The Maldives has a rich history dating back over 2,500 years. Originally settled by Dravidian people from South India and Sri Lanka, the islands later became an important stop on ancient maritime trade routes. Buddhism was the dominant religion until the 12th century when Islam was adopted. The Maldives was a British protectorate from 1887 to 1965, gaining full independence on July 26, 1965. Today, it's known for environmental conservation efforts and sustainable luxury tourism."
        },
        
        cuisine: {
            title: "Island Flavors",
            dishes: [
                {
                    name: "Mas Huni",
                    description: "Traditional breakfast dish of tuna, coconut, onion, and chili mixed together, served with roshi (flatbread) and sweetened tea."
                },
                {
                    name: "Garudhiya",
                    description: "Clear fish broth soup served with rice, lime, chili, and onions - the soul food of Maldives."
                },
                {
                    name: "Bis Keemiya",
                    description: "Savory pastry filled with tuna, egg, and cabbage - a popular Maldivian snack."
                },
                {
                    name: "Fresh Seafood",
                    description: "Grilled lobster, tuna steaks, reef fish - incredibly fresh and prepared in various styles at resort restaurants."
                }
            ]
        },
        
        attractions: [
            "Overwater Bungalow Stays",
            "Scuba Diving & Snorkeling in coral reefs",
            "Manta Ray & Whale Shark encounters",
            "Bioluminescent Beach (Vaadhoo Island)",
            "Male City - National Museum & Grand Friday Mosque",
            "Island Hopping Tours",
            "Water Sports - Jet skiing, Parasailing, Kayaking",
            "Sunset Dolphin Cruises"
        ],
        
        tips: [
            "Best time to visit: November to April (dry season)",
            "Book resorts in advance - many islands have one resort only",
            "Seaplane transfers offer stunning aerial views",
            "Respect local customs in Male and inhabited islands",
            "Bring reef-safe sunscreen to protect coral ecosystems"
        ]
    },

    "taj-mahal": {
        id: "taj-mahal",
        name: "Taj Mahal, Agra, India",
        image: "Taj-Mahal.jpg",
        tagline: "An eternal symbol of love",
        location: "Agra, Uttar Pradesh, India",
        description: "The Taj Mahal is an ivory-white marble mausoleum and one of the Seven Wonders of the World. Built by Mughal Emperor Shah Jahan in memory of his beloved wife Mumtaz Mahal, it stands as the ultimate testament to eternal love. Its perfect symmetry, intricate marble inlay work, and stunning gardens make it one of humanity's greatest architectural achievements.",
        
        history: {
            title: "A Monument to Eternal Love",
            content: "Construction began in 1632 and took 22 years to complete, employing over 20,000 artisans and craftsmen from across India and Central Asia. Emperor Shah Jahan built this magnificent mausoleum for his third wife, Mumtaz Mahal, who died giving birth to their 14th child. The emperor was later imprisoned by his son and spent his final years gazing at the Taj Mahal from his cell window. Both are now entombed together in the monument. The Taj Mahal combines Persian, Islamic, and Indian architectural styles in perfect harmony."
        },
        
        cuisine: {
            title: "Mughlai Delicacies",
            dishes: [
                {
                    name: "Petha",
                    description: "Agra's famous translucent soft candy made from ash gourd, available in various flavors. A must-buy souvenir!"
                },
                {
                    name: "Mughlai Cuisine",
                    description: "Rich curries, biryanis, and kebabs - try dishes like butter chicken, mutton korma, and seekh kebabs."
                },
                {
                    name: "Bedai and Jalebi",
                    description: "Traditional breakfast of deep-fried bread with spicy potato curry, followed by sweet spiral-shaped jalebi."
                },
                {
                    name: "Dalmoth",
                    description: "Spicy and crunchy snack mix made from lentils, nuts, and spices - perfect for taking home."
                }
            ]
        },
        
        attractions: [
            "Taj Mahal Main Mausoleum",
            "Taj Museum inside the complex",
            "Mehtab Bagh (Moonlight Garden) - best sunset view of Taj",
            "Agra Fort (UNESCO World Heritage Site)",
            "Tomb of Itimad-ud-Daulah (Baby Taj)",
            "Fatehpur Sikri (abandoned Mughal city nearby)",
            "Kinari Bazaar for shopping",
            "Yamuna River boat rides"
        ],
        
        tips: [
            "Visit at sunrise for the best light and fewer crowds",
            "Taj is closed on Fridays for prayers",
            "Book tickets online to skip long queues",
            "No food, tobacco, or large bags allowed inside",
            "Hire a certified guide for rich historical context",
            "Best view for photography: from Mehtab Bagh garden across the river"
        ]
    }
};

// Add more destinations as needed - I've created 6 detailed ones as examples
// You can easily add the rest following the same structure