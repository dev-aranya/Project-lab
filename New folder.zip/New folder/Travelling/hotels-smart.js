let allHotels = [];
let filteredHotels = [];

async function loadHotels() {
    try {
        const res = await fetch("http://localhost:5000/hotels");
        allHotels = await res.json();
        filteredHotels = allHotels;
        displayHotels(allHotels);
    } catch (err) {
        console.error("Error loading hotels:", err);
    }
}

function displayHotels(hotels) {
    const container = document.getElementById("hotel-list");
    
    if (hotels.length === 0) {
        container.innerHTML = `
            <div class="no-results">
                <h3>No hotels found</h3>
                <p>Try adjusting your search</p>
            </div>
        `;
        return;
    }

    container.innerHTML = hotels.map(hotel => `
        <div class="hotel-card" onclick="openHotel('${hotel._id}')">
            <img src="${hotel.image}" alt="${hotel.name}">
            <div class="hotel-info">
                <h2>${hotel.name}</h2>
                <p class="location">${hotel.location}</p>
                <p class="rating">⭐ ${hotel.rating}/10</p>
                <p class="review">"${hotel.description}"</p>
                <p class="price">$${hotel.price} nightly</p>
            </div>
        </div>
    `).join("");
}

// Smart Search Function
function smartSearch(query) {
    if (!query || query.trim() === '') {
        hideDropdown();
        return;
    }

    query = query.toLowerCase();
    
    // Search across multiple fields
    const results = allHotels.filter(hotel => {
        const matchName = hotel.name.toLowerCase().includes(query);
        const matchLocation = hotel.location.toLowerCase().includes(query);
        const matchRating = hotel.rating.toString().includes(query);
        const matchPrice = hotel.price.toString().includes(query);
        
        return matchName || matchLocation || matchRating || matchPrice;
    });

    // Categorize results
    const byName = results.filter(h => h.name.toLowerCase().includes(query));
    const byLocation = results.filter(h => h.location.toLowerCase().includes(query) && !byName.includes(h));
    const byRating = results.filter(h => h.rating.toString().includes(query) && !byName.includes(h) && !byLocation.includes(h));
    const byPrice = results.filter(h => h.price.toString().includes(query) && !byName.includes(h) && !byLocation.includes(h) && !byRating.includes(h));

    showDropdown(byName, byLocation, byRating, byPrice, query);
}

function showDropdown(byName, byLocation, byRating, byPrice, query) {
    const dropdown = document.getElementById('searchDropdown');
    const content = document.getElementById('dropdownContent');
    
    let html = '';

    // Results by Name
    if (byName.length > 0) {
        html += `
            <div class="dropdown-section">
                <div class="dropdown-section-title">Hotels by Name</div>
                ${byName.slice(0, 5).map(hotel => `
                    <div class="dropdown-item" onclick="selectHotel('${hotel._id}')">
                        <div class="dropdown-item-name">${highlightText(hotel.name, query)}</div>
                        <div class="dropdown-item-details">
                            ${hotel.location}
                            <span class="dropdown-item-rating">⭐ ${hotel.rating}</span>
                            <span class="dropdown-item-price">$${hotel.price}/night</span>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    // Results by Location
    if (byLocation.length > 0) {
        html += `
            <div class="dropdown-section">
                <div class="dropdown-section-title">Hotels by Location</div>
                ${byLocation.slice(0, 5).map(hotel => `
                    <div class="dropdown-item" onclick="selectHotel('${hotel._id}')">
                        <div class="dropdown-item-name">${hotel.name}</div>
                        <div class="dropdown-item-details">
                            ${highlightText(hotel.location, query)}
                            <span class="dropdown-item-rating">⭐ ${hotel.rating}</span>
                            <span class="dropdown-item-price">$${hotel.price}/night</span>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    // Results by Rating
    if (byRating.length > 0) {
        html += `
            <div class="dropdown-section">
                <div class="dropdown-section-title">Hotels by Rating</div>
                ${byRating.slice(0, 5).map(hotel => `
                    <div class="dropdown-item" onclick="selectHotel('${hotel._id}')">
                        <div class="dropdown-item-name">${hotel.name}</div>
                        <div class="dropdown-item-details">
                            ${hotel.location}
                            <span class="dropdown-item-rating">⭐ ${highlightText(hotel.rating.toString(), query)}</span>
                            <span class="dropdown-item-price">$${hotel.price}/night</span>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    // Results by Price
    if (byPrice.length > 0) {
        html += `
            <div class="dropdown-section">
                <div class="dropdown-section-title">Hotels by Price</div>
                ${byPrice.slice(0, 5).map(hotel => `
                    <div class="dropdown-item" onclick="selectHotel('${hotel._id}')">
                        <div class="dropdown-item-name">${hotel.name}</div>
                        <div class="dropdown-item-details">
                            ${hotel.location}
                            <span class="dropdown-item-rating">⭐ ${hotel.rating}</span>
                            <span class="dropdown-item-price">${highlightText('$' + hotel.price, query)}/night</span>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    if (html === '') {
        html = '<div class="no-results">No hotels found matching your search</div>';
    }

    content.innerHTML = html;
    dropdown.classList.add('active');
}

function highlightText(text, query) {
    const regex = new RegExp(`(${query})`, 'gi');
    return text.toString().replace(regex, '<mark style="background: #ffdd00; padding: 2px;">$1</mark>');
}

function hideDropdown() {
    document.getElementById('searchDropdown').classList.remove('active');
}

function selectHotel(id) {
    hideDropdown();
    openHotel(id);
}

function openHotel(id) {
    window.location.href = `hotel.html?id=${id}`;
}

// Advanced Filters
function toggleAdvancedFilters() {
    const panel = document.getElementById('advancedFilters');
    panel.classList.toggle('active');
}

function applyAdvancedFilters() {
    const minRating = parseFloat(document.getElementById('minRatingFilter').value) || 0;
    const minPrice = parseFloat(document.getElementById('minPriceFilter').value) || 0;
    const maxPrice = parseFloat(document.getElementById('maxPriceFilter').value) || Infinity;

    filteredHotels = allHotels.filter(hotel => {
        return hotel.rating >= minRating && 
               hotel.price >= minPrice && 
               hotel.price <= maxPrice;
    });

    displayHotels(filteredHotels);
    document.getElementById('smartSearch').value = '';
    hideDropdown();
}

function clearAdvancedFilters() {
    document.getElementById('minRatingFilter').value = '0';
    document.getElementById('minPriceFilter').value = '';
    document.getElementById('maxPriceFilter').value = '';
    filteredHotels = allHotels;
    displayHotels(allHotels);
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    loadHotels();
    
    const searchInput = document.getElementById('smartSearch');
    
    // Real-time search with debounce
    let searchTimeout;
    searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            smartSearch(e.target.value);
        }, 300);
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.search-wrapper')) {
            hideDropdown();
        }
    });

    // Show dropdown when focusing on search
    searchInput.addEventListener('focus', (e) => {
        if (e.target.value.trim() !== '') {
            smartSearch(e.target.value);
        }
    });
});