const express = require("express");
const router = express.Router();
const Hotel = require("../models/hotel.model");

// GET all hotels
router.get("/", async (req, res) => {
    try {
        const hotels = await Hotel.find();
        res.json(hotels);
    } catch (error) {
        res.status(500).send(error);
    }
});

// GET single hotel
router.get("/:id", async (req, res) => {
    try {
        const hotel = await Hotel.findById(req.params.id);
        res.json(hotel);
    } catch (error) {
        res.status(500).send(error);
    }
});

// POST review
router.post("/:id/review", async (req, res) => {
    try {
        const { user, rating, comment } = req.body;
        const hotel = await Hotel.findById(req.params.id);

        hotel.reviews.push({ user, rating, comment });

        // Recalculate average rating
        hotel.rating = 
            hotel.reviews.reduce((sum, r) => sum + r.rating, 0) /
            hotel.reviews.length;

        await hotel.save();
        res.json(hotel);
    } catch (error) {
        res.status(500).send(error);
    }
});

module.exports = router;
