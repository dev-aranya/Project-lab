const express = require("express");
const Contact = require("../models/contact.model");
const router = express.Router();

router.post("/contact", async (req, res) => {
    console.log("Received body:", req.body); 
    try {
        const { name, phone, email, message } = req.body;

        const newContact = new Contact({
            name,
            phone,
            email,
            message
        });

        await newContact.save();
        res.json({ success: true, message: "Message saved successfully!" });

    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

module.exports = router;
