async function loadHotels() {
    try {
        const res = await fetch("http://localhost:5000/hotels");
        const hotels = await res.json();

        const container = document.getElementById("hotel-list");

        container.innerHTML = hotels.map(hotel => `
            <div class="hotel-card" onclick="openHotel('${hotel._id}')">
                <img src="${hotel.image}" alt="${hotel.name}">
                <div class="hotel-info">
                    <h2>${hotel.name}</h2>
                    <p class="location">${hotel.location}</p>
                    <p class="rating">⭐ ${hotel.rating}/10</p>
                    <p class="review">${hotel.reviewSnippet || ""}</p>
                    <p class="price">${hotel.price} nightly <br><strong>${hotel.totalPrice}</strong></p>
                    <p class="date">${hotel.dateRange}</p>
                </div>
            </div>
        `).join("");
    } catch (err) {
        console.error("Error loading hotels:", err);
    }
}

function openHotel(id) {
    window.location.href = `hotel.html?id=${id}`;
}

loadHotels();
