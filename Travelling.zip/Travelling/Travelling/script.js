// Contact Form Handler
// document.addEventListener("DOMContentLoaded", () => {
//   const form = document.getElementById("contactForm");
//   if (form) {
//     form.addEventListener("submit", (e) => {
//       e.preventDefault();
//       document.getElementById("response").innerText = "✅ Thank you! We’ll get back to you soon.";
//       form.reset();
//     });
//   }
// });

// // Example: You could load hotel data dynamically in the future
// console.log("Hotels page loaded successfully!");
document.querySelector("form").addEventListener("submit", async (e) => {
    e.preventDefault();

    const data = {
        name: document.querySelector("input[name='name']").value,
        phone: document.querySelector("input[name='phone']").value,
        email: document.querySelector("input[name='email']").value,
        message: document.querySelector("textarea[name='message']").value
    };

    const res = await fetch("http://localhost:5000/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    });

    const result = await res.json();
    alert(result.message);
});
