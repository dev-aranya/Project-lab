const mongoose = require("mongoose");
const Hotel = require("./models/hotel.model");

mongoose.connect("mongodb://localhost:27017/travelDB")
    .then(() => console.log("MongoDB Connected"))
    .catch(err => console.log(err));

const hotels = [
    {
        name: "Warren Street Hotel",
        location: "86 Warren Street, Tribeca, New York, NY 10007, United States",
        description: "Design-forward, chic, wonderful service, comfortable.",
        price: 310,   // NUMBER
        image: "new_hotel3.jpg",
        rating: 9.1,
        reviews: []
    },
    {
        name: "The Surrey, A Corinthia Hotel",
        location: "20 East 76th Street, Upper East Side, New York, NY 10021, United States",
        description: "Exceptional",
        price: 170,   // NUMBER
        image: "new_hotel4.jpg",
        rating: 9.1,
        reviews: []
    },
    
    {
        name: "Hard Rock Hotel Maldives",
        location: "Emboodhoo Lagoon",
        description: "The food, service, and staff were excellent.",
        price: 190,   // NUMBER
        image: "mal_hotel1.webp",
        rating: 9.4,
        reviews: []
    },
    
    {
        name: "Sheraton Maldives Full Moon Resort & Spa",
        location: "Furanfushi Island",
        description: "Amazing for a quiet vacation.",
        price: 220,   // NUMBER
        image: "mal_hotel2.webp",
        rating: 8.7,
        reviews: []
    },
    {
        name: "Kurumba Maldives",
        location: "Vihamanaafushi",
        description: "The property is very clean as well as the beach around the property. Excellent place.",
        price: 210,   // NUMBER
        image: "mal_hotel3.webp",
        rating: 9.2,
        reviews: []
    },
    {
        name: "Bandos Maldives",
        location: "Bandos Island",
        description: "Hotel was great with wonderful staff and plenty to do. The new restaurant was really good and the house reef had great snorkeling.",
        price: 220,   // NUMBER
        image: "mal_hotel4.avif",
        rating: 8.9,
        reviews: []
    },
     {
        name: "Grand Palace Hotel & Resort",
        location: "22, SA Point, Dhaka 1000, Bangladesh",
        description: "An absolutely delightful stay!",
        price: 170,   // NUMBER
        image: "ban-hotel1.jpg",
        rating: 9.1,
        reviews: []
    },
     {
        name: "Le Meridien Dhaka",
        location: "79/A Commercial Area Road, Dhaka 1229, Bangladesh",
        description: "Le Méridien Dhaka is a top-tier luxury hotel offering an exceptional blend of comfort, elegance, and world-class service",
        price: 320,   // NUMBER
        image: "ban-hotel2.webp",
        rating: 9.0,
        reviews: []
    },
     {
        name: "La Vista Suites Sylhet",
        location: "Vip Road, Sheikhpara Street, Sylhet 3100, Bangladesh",
        description: "The premium amenities with spa and wellness facilities offered us an excellent experience",
        price: 230,   // NUMBER
        image: "ban-hotel3.webp",
        rating: 8.7,
        reviews: []
    },
     {
        name: "Broadwick Soho",
        location: "20 Broadwick Street , Westminster Borough, London, W1F 8HT, United Kingdom",
        description: "Fun decor and lots of luxury extra touches",
        price: 320,   // NUMBER
        image: "lon-hotel1.jpg",
        rating: 9.7,
        reviews: []
    },
     {
        name: "The Spice of Life",
        location: "6 Moor St, Westminster Borough, London, W1D 5NA, United Kingdom ",
        description: "Fantastic Boutique hotel.",
        price: 220,   // NUMBER
        image: "lon-hotel2.jpg",
        rating: 8.9,
        reviews: []
    },
     {
        name: "Henrys Townhouse Marylebone, London",
        location: "24 Upper Berkeley Street, Westminster Borough, London, W1H 7QH, United Kingdom",
        description: "Perfect, relaxing, quirky, interesting, peaceful, welcoming, luxury, attentive.",
        price: 190,   // NUMBER
        image: "lon-hotel3.jpg",
        rating: 9.7,
        reviews: []
    },
     {
        name: "Park Hyatt London River Thames",
        location: "7 Nine Elms Lane, Wandsworth, London, SW85PH, United Kingdom",
        description: "Amazing hotel room, great views, questionable service.",
        price: 230,   // NUMBER
        image: "lon-hotel4.jpg",
        rating: 9.4,
        reviews: []
    },
     {
        name: "NoMad London",
        location: "28 Bow Street, Westminster Borough, London, WC2E 7AW, United Kingdom",
        description: "Unique, historical, surprising.",
        price: 220,   // NUMBER
        image: "lon-hotel5.jpg",
        rating: 8.7,
        reviews: []
    },
     {
        name: "Relais Christine",
        location: "3, Rue Christine, 6th arr., 75006 Paris, France",
        description: "Luxury and location in one. Best hotel for an authentic Parisian stay!.",
        price: 210,   // NUMBER
        image: "paris1.jpg",
        rating: 9.1,
        reviews: []
    },
     {
        name: "Hôtel Eldorado Paris",
        location: "18 Rue des Dames, 17th arr., 75017 Paris, France",
        description: "Was a beautiful few days for our ‘mini moon’",
        price: 190,   // NUMBER
        image: "paris2.jpg",
        rating: 9.2,
        reviews: []
    },
     {
        name: "La Fantaisie",
        location: "24 RUE CADET 75009 PARIS, 9th arr., 75009 Paris, France",
        description: "Lovely boutique hotel in a great location.",
        price: 240,   // NUMBER
        image: "paris3.jpg",
        rating: 9.7,
        reviews: []
    },
     {
        name: "Hôtel Les Deux Girafes",
        location: "23 Passage Beslay, 11th arr., 75011 Paris, France ",
        description: "The Staffs hospitality was exceptional!",
        price: 190,   // NUMBER
        image: "paris4.jpg",
        rating: 9.3,
        reviews: []
    },
     {
        name: "brand-new hotel, a 3-minute walk from Asakusa Kuramae Statio",
        location: "Tokyo-to, Tokyo, 東京都台東区藏前2-7-6, Japan",
        description: "Exceptional.",
        price: 220,   // NUMBER
        image: "japan2.jpg",
        rating: 8.7,
        reviews: []
    },
     {
        name: "Hotel K5",
        location: "Tokyo-to, Tokyo, Chuo-Ku Nihonbashikabuto-Cho3-5, Japan",
        description: "Gorgeous stay with K5 - loved the design and the room functionality.",
        price: 220,   // NUMBER
        image: "japan1.jpg",
        rating: 8.7,
        reviews: []
    },
   
     {
        name: "TRUNK(HOTEL) YOYOGI PARK",
        location: "Tokyo-to, Tokyo, 1-15-2 Tomigaya, Shibuya-ku, Japan",
        description: "really lovely zen hotel. great staff!..",
        price: 220,   // NUMBER
        image: "japan3.jpg",
        rating: 9.6,
        reviews: []
    },
   
     {
        name: "PETALS TOKYO - Floating Hotel",
        location: "Tokyo-to, Tokyo, Shinagawa-ku Higashishinagawa 2-1, Japan",
        description: "Imagine a hotel room that feels like you’re floating on a cloud.",
        price: 220,   // NUMBER
        image: "japan4.jpg",
        rating: 9.3,
        reviews: []
    },
   
     {
        name: "HOTEL ALL IN TOKYO Asakusabashi",
        location: "Tokyo-to, Tokyo, 4-3-3 Asakusabashi, Taito-Ku, Japan",
        description: "Gorgeous stay with K5 - loved the design and the room functionality.",
        price: 220,   // NUMBER
        image: "japan1.jpg",
        rating: 9.4,
        reviews: []
    },
   
     {
        name: "Capella Shanghai, Jian Ye Li",
        location: "No. 480 West Jianguo Road, Jianye Lane, Xuhui District, Xuhui, 200031 Shanghai, China ",
        description: "Amazing cultural experience in tree lined historical setting of old shanghai.",
        price: 230,   // NUMBER
        image: "china1.jpg",
        rating: 9.6,
        reviews: []
    },
   
    

    // Add more hotels here, same format
];

async function seed() {
    await Hotel.deleteMany({});
    await Hotel.insertMany(hotels);
    console.log("Hotels inserted!");
    mongoose.connection.close();
}

seed();
