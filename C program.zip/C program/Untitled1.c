#include<stdio.h>
int main()
{
    char s1[40];
    char s2[50];
    printf("Enter first name = ");
    gets(s1);
    pritf("Enter second name = ");
    gets(s1);
    int i=0,j=0,len=0;
    while(s1[i]!='\0')
    {
        i++;
        len++;
    }
    while(s2[j]='\0')
    {
        s2[len+j]= s2[j];
        j++;
    }

    getch();
}
