#include <stdio.h>
int get_strlen(char str[])
{
    int i=0,length;
    while(str[i])
    {
        i++;
    }
    length=i;
    return length;
}

int main()
{
    char str[50];
    int length;
    gets(str);
    length= get_strlen(str);
    printf("Length of string is %d\n",length);
}
