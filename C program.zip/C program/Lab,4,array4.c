#include<stdio.h>
int main()
{
    int i=0,n,decimal;
    int binary[32];
    printf("Enter decimal number = ");
    scanf("%d",&decimal);
    if(decimal==0)
    {
        printf("Binary = 0");
    }
    else
    {
        while(decimal>0)
        {
            binary[i]=decimal%2;
            decimal=decimal/2;
            if(decimal==0)
            {
                n=i;
            }
            i++;
        }
        printf("\nBinary = ");
    }
    for(int a=n;a>=0;a--)
    {
        printf("%d",binary[a]);
    }
}
