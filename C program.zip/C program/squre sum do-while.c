#include<stdio.h>
int main()
{
  int i,n,x,sum=0;
  printf("Enter Number = ");
  scanf("%d",&n);
  i=1;
  do{
        x=i*i;
    sum=sum+x;
    printf("%d",sum);
    i++;
  }
    while(i<=n);

}
