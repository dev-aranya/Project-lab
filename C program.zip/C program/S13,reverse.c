#include<stdio.h>
int main()
{
    char s1[30]="Aranya Debnath Ovi";
    char s2[50];
    int i=0,j,len=0;
    while (s1[i]!='\0')
    {
        i++;
        len++;
    }
    for(j=0,i=len-1;i>=0;i--,j++)
    {
        s2[j]=s1[i];
    }
    printf("S1=%s\n",s1);
    printf("s2=%s\n",s2);
}
