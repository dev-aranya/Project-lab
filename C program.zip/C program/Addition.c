#include<stdio.h>
int main (){
int n1,n2,sum;
printf("Enter two numbers = ");
scanf("%d %d",&n1,&n2);
sum=n1+n2;
printf("The sum is =%d\n",sum);
return 0;

}
