#include<stdio.h>
int main()
{
    int n1,n2;
    printf("Enter 2 numbers = ");
    scanf("%d %d",&n1,&n2);
    n1=n1-n2;
    n2=n1+n2;
    n1=n2-n1;

    printf("n1=%d\n",n1);
    printf("n2=%d\n",n2);


}
