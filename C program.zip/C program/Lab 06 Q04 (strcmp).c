#include<stdio.h>
void get_strcmp(char str1[],char str2[])
{
    int i,count=0;
    for(i=0; (str1[i]!='\0') || (str2[i]!='\0') ; i++)
    {
        if(str1[i]== str2[i])
        {
            count= 1;

        }
        else count=0;
    }
    if(count==1)
    {
        printf("Equal");

    }
    else
    {
        printf("Not Equal");
    }

}

int main()
{
    char str1[100],str2[100];
    gets(str1);
    gets(str2);
    get_strcmp(str1, str2);
}

