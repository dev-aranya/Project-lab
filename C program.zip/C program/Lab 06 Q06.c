#include<stdio.h>
int oddeven(int x)
{
    if(x%2!=0)
        return 1;
    else
        return 0;
}


int leap_year(int y)
{
    int t=0;
    if(y%400==0 || (y%100!=0 && y%4==0))
    {
        t=1;
    }
    return t;
}

int prime(int n)
{
    int i, t=0;
    for(i=2; i<n/2; i++)
    {
        if(n%i==0)
        {
            t=1;
            break;
        }
    }
    if(t==1 || n==1)
        return 0;
    else
        return 1;
}

int get_fact(int x)
{
    int fact=1;
    for(int i=1; i<=x; i++)
    {
        fact=fact*i;
    }
    return fact;
}

void get_fibo (int n)
{
    int first=0,second=1,count=0,fibo;

    while(count<n)
    {
        if(count<=1)
            fibo=count;
        else{
            fibo= first + second;
            first = second;
            second = fibo;
        }
        printf("%d ",fibo);
        count++;
    }
    printf("\n");
}


int main()
{
    int n,a;
    int result;
    printf("1. Odd or Even\n");
    printf("2. Leap Year\n");
    printf("3. Prime or Not Prime\n");
    printf("4. Factorial\n");
    printf("5. Fibonacci Series\n");
    printf("6. Exit\n");
    scanf("%d",&n);

    // Even Odd
    if(n==1)
    {
        printf("Input value: ");
        scanf("%d",&a);
        if(a==0)
            printf("ZERO\n");
        else
        {
        result= oddeven(a);
        if(result==1)
            printf("ODD\n");
        else
            printf("Even\n");
        }
    }

    //Leap Year
    if(n==2)
    {
        printf("Input year: ");
        scanf("%d",&a);
        result= leap_year(a);
        if(result==1)
        printf("Leap Year\n");
    else
        printf("Not Leap Year\n");
    }

    //Prime or Not Prime
    if(n==3)
    {
        printf("Input Value: ");
        scanf("%d",&a);
        result= prime(a);
         if(result==1)
        printf("Prime\n");
    else
        printf("Not Prime\n");
    }

    //Factorial
    if(n==4)
    {
        printf("Input Value: ");
        scanf("%d",&a);
        result= get_fact(a);
        printf("Factorial of %d is %d\n",a,result);
    }

    //Fibonacci Series
    if(n==5)
    {
        printf("Input Value: ");
        scanf("%d",&a);
        get_fibo(a);

    }

    if(n==6)
    printf("\n");
}
