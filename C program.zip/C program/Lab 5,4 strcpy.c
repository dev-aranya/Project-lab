#include<stdio.h>
int main()
{
    char str[]= "  ";
    printf("Enter name = ");
    gets(str);
    char tar[50];
    strcpy(tar,str);
    printf("Copy string=%s\n",tar);

}
