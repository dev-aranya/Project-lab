#include<stdio.h>
int main()
{
    int n1,n2,result;
    printf("Enter 2 numbers = ");
    scanf("%d %d",&n1,&n2);
    while(n2!=0)
    {
        result=n1%n2;
        n1=n2;
        n2=result;

    }
    printf("GCD=%d",n1);
}
