#include<stdio.h>
int main()
{

    float base,height,area;
    printf("Enter base and height = ");
    scanf("%f %f",&base,&height);
    area=(float)1/2*base*height;
    printf("Triangle area is = %.2f\n",area);


    getch ();

}
