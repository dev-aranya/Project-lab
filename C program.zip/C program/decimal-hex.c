#include<stdio.h>
int main()
{

    int num;
    printf("Decimal Number = ");
    scanf("%d",&num);
    printf("Hexa-decimal Number =%x",num);

    getch();


}
