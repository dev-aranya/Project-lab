#include<stdio.h>

void get_strrev(char str[])
{
    char rev;
    int i=0,j,length;
    while(str[i])
    {
        i++;
    }
    length=i;
    for(i=0,j=length-1; i<j; i++,j--)
    {
        rev=str[i];
        str[i]= str[j];
        str[j]= rev;
    }

    printf("Reverse: %s\n",str);
}

int main()
{
    char str[50];
    gets(str);
    get_strrev(str);
}
