#include<stdio.h>
int main()
{
    int n;
    printf("Enter any positive number = ");
    scanf("%d",&n);
    if(n%2==0)
        printf("\nEven\n");
    else
        printf("Odd\n");
}
