#include<stdio.h>
int main()
{

    int m;
    printf("enter any marks");
    scanf("%d",&m);
    if(m>=80 && m<=100)
        printf("A+");
    else if(m>=70 && m<=79)
        printf("A");
    else if(m>=60 && m<=69)
    printf("B+");
    else if("m>=50 && m<=59")
        printf("B");
    else if("m>=40  && m<=49")
        printf("C");
    else
        printf("Fail");

}
