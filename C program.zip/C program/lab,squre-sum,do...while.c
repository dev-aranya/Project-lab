#include<stdio.h>
int main()
{
    int x,n,sum=0;
    printf("Enter any number = ");
    scanf("%d",&n);
    x=1;

    do
    {
        printf("%d\n",sum);
        x++;
        sum=sum+x*x;
    }while(x<=n);

}
