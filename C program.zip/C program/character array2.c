#include<stdio.h>
int main()
{
    char str[]="ARANYA DEBNATH";
    printf("str=%s\n",str);
}
