#include<stdio.h>
int main()
{
    int x,y;
    printf("Enter any number = ");
    scanf("%d",&x);

    printf("%d\n",x++);
    printf("%d\n",x);
    printf("%d\n",++x);
    printf("%d\n",x);
    printf("%d\n",x--);
    printf("%d\n",x);
    printf("%d\n",--x);
    printf("%d\n",x);


}
