#include<stdio.h>
int main()
{
    int x,r,s,t;
    printf("Enter any years = ");
    scanf("%d",&x);
    r=x%100;
    s=x%400;
    t=x%4;
    if(r==0){

        if(s==0)
            printf("Leap Year");
        else
            printf("Not Leap Year");

    }

    else{
            if(t==0)
            printf("Leap Year");
    else
        printf("Not Leap Year");

    }


    }






