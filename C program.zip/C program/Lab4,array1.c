#include<stdio.h>
int main()
{
    int i,b,n,a;
    printf("How many numbers = ");
    scanf("%d",&n);
    int x[n];
    printf("Enter number = ");
    for(i=0;i<n;i++)
    {
        scanf("%d",&x[i]);
    }
    if(n%2!=0)
    {
        a=(n+1)/2;
        printf("Median array of element = %d\n",x[a-1]);
    }
    if(n%2==0)
    {
        b=n/2;
        printf("Median array of elements =%d %d",x[b-1],x[b]);
    }
}
