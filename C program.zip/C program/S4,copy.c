#include<stdio.h>
int main()
{
    char source[]="C programing,Aranya Debanath";
    char target[20];

    strcpy(target ,source);

    printf("Source string = %s\n",source);
     printf("target string = %s\n",target);

}
