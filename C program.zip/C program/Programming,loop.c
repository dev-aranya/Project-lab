#include<stdio.h>
int main()
{
    int i;
    for(i=1; i<=5; i++)
    {
        printf("Aranya Debnath Ovi\n");
        printf("%d\n",i);

    }

}
