#include<stdio.h>
int main(){

int n1,n2,sum;
float avg;
printf("Enter 2 numbers = ");
scanf("%d %d",&n1,&n2);
sum=n1+n2;
printf("SUM =%d\n",sum);
avg= sum/2.0;
printf("AVG =%.2f\n",avg);

}
