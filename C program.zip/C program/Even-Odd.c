#include<stdio.h>
int main()
{

    int x,r;
      printf("Enter any number= ");
    scanf("%d",&x);

    r=x%2;

    if(r==0){
        printf("Even");

    }
    if(r==1){
        printf("Odd");
    }




}
