#include<stdio.h>
int main()
{
    int array1[30],array2[30],i,n;

    printf("How many numbers = ");
    scanf("%d",&n);

    for(i=0;i<n;i++)
    {
        scanf("%d",&array1[i]);
    }
        printf("Array1 = ");
    for(i=0;i<n;i++)
    {
        Printf("%d ",array1[i]);
    }

     for(i=0;i<n;i++)
    {
        array2[i]=array1[i];
    }
         printf("\nArray2 = ");
    for(i=0;i<n;i++)
    {
        Printf("%d ",array2[i]);
    }
    getch();
}
