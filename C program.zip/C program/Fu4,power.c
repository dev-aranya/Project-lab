#include<stdio.h>
 void calculatepower(double base,double exp)
{
    double result=1,i;
    for(i=1;i<=exp;i++)
    {
        result = result*base;
    }
    printf("%.2lf\n",result);

}
int main()
{
    double base,exp;
    printf("Enter base & exponent = ");
    scanf("%lf %lf",&base,&exp);
    calculatepower(base,exp);

}

