
#include<stdio.h>
int main()
{

  double x;
  printf("Enter value= ");
  scanf("%lf",&x);
  double result=log(x);
  printf("%lf\n",result);

}
