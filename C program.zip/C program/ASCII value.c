#include<stdio.h>
int main()
{
    char ch;
    printf("Enter any ASCII character = ");
    scanf("%c",&ch);
    printf("The ASCII value = %d",ch);
    return 0;


}
