#include<stdio.h>
int main()
{
    char str[100];
    scanf ("%[^\n]",str);
    int i,c=0;
    for(i=0;i<str[i];i++)
    {
        printf("%c",str[i]);

    }
    if(str[i]=='a' || str[i]=='e' || str[i]=='i' || str[i]=='o' || str[i]=='u' ||
     str[i]=='A' || str[i]=='E' || str[i]=='I' || str[i]=='O' || str[i]=='U')
    {
        c=c+i;
        printf();
    }
}
