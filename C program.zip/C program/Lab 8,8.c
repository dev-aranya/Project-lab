#include<stdio.h>
#include<stdlib.h>
int main()
{
    FILE *f1;
    f1=fopen("csein.txt","r");
    if(f1==NULL)
    {
        printf("File does not exit");
    }
    int n;
    printf("How many characters : ");
    scanf("%d",&n);
    char ch;
    fseek(f1,-n,2);
    while(fscanf(f1,"%c",&ch)==1)
    {
        printf("%c",ch);
    }
    printf("\n");
    rewind(f1);
    for(int i=0;i<n;i++)
    {
        fscanf(f1,"%c",&ch);
        printf("%c",ch);
    }
}
