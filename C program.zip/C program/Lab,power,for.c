#include<stdio.h>
int main()
{
    int x,y,result=1,i;
    printf("Enter 2 number = ");
    scanf("%d %d",&x,&y);
    for(i=1;i<=y;i++)
    {
       result=result*x;
    }
    printf("result=%d\n",result);

}
