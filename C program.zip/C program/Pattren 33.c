#include<stdio.h>
int main()
{
    int i,j,n;
    printf("Enter num = ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        for(j=n;j<=n-i;j++)
        {
            printf(" ");
        }
        for(j=1;j<=i;j++)
        {
            printf("%d ",j);
        }
        printf("\n");
    }
}
