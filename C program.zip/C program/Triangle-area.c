#include<stdio.h>
int main()
{
    float base,height,area;
    printf("Enter any Base and Height = ");
    scanf("%f %f",&base,&height);
    area=0.5*base*height;
    printf("The Triangle-area is =%.2f\n",area);


}
