#include<stdio.h>
#include<math.h>

int main()
{
    int n=4;
    printf("%f",pow(n,2));

    return 0;
}
