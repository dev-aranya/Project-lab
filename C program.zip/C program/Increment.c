#include<stdio.h>
int main()
{
   int x,y;
   printf("Enter any number = ");
   scanf("%d",&x);
   y=x++;
   printf("X=%d\n",x);
   printf("Y=%d\n",y);


}
