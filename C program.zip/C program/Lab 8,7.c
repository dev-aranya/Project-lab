#include<stdio.h>
#include<stdlib.h>
void bubble_sort(int *arr,int size,FILE *file3)
{
    for(int i=0;i<size-1;i++)
    {
        for(int j=0;j<size-i-1;j++)
        {
            if(arr[j]>arr[j+1])
            {
                //swaping arr[j] and arr[j+1]
                int temp = arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
    }
    for(int m=0;m<size;m++)
    {
        fprintf(file3,"%d\n",arr[m]);
        printf("%d\n",arr[m]);
    }
}
int marge(int *arr1,int *arr2,int i,int j,int arrlen,FILE *file3)
{
    int p=0,m=0;
    //printf("%d%d\n",i.j);
    while(p<=j-1)
    {
        arr1[i]=arr2[p];
        p++;
        i++;
    }
    //printf("%d\n",i);
    bubble_sort(arr1,arrlen,file3);
}
int main()
{
    FILE *file1,*file2, *file3;
    int num1,num2,arr1[50],arr2[100],i=0,j=0;
    file1= fopen("file1.txt","r");
    file2= fopen("file2.txt","r");
    file3= fopen("third.txt","a");

    if(file1==NULL)
    {
        printf("Input File Not Found");
        exit(0);
    }
    while(fscanf(file2,"%d",&num2)==1)
    {
        arr2[j]=num2;
        j++;
    }
    //printf("%d\n",j);
    int arrlen=i+j;
    marge(arr1,arr2,i,j,arrlen,file3);
    fclose(file1);
    fclose(file2);
    return 0;
}
