#include<stdio.h>  //1.5+2.5+3.5+.....+n
int main()
{
  float i,n,sum=0;
  printf("Enter any number = ");
  scanf("%f",&n);
  for(i=1;i<=n;i++)
  {
      sum=sum+i;
  }
    printf("sum=%.2f\n",sum);
    getch ();
}
