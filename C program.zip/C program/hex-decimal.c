#include<stdio.h>
int main()

{
    int num;
    printf("Hexa-decimal Number = ");
    scanf("%x",&num);
    printf("Decimal Number =%d",num);

    getch();


}
