#include<stdio.h>
int main()
{
    int x;
    printf("Enter any number =");
    scanf("%d",&x);
    if(x>=80){
        printf("First Division");

    }
    if(x>=60 && x<=79){
        printf("Second Division");
    }
    if(x>=40 && x<=59){
        printf("Third Division");

    }
    if(x<40){
        printf("Fail");
    }





}
