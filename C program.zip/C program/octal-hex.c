#include<stdio.h>
int main()
{

    int num;
    printf("Octal number = ");
    scanf("%o",&num);
    printf("Hexa-decimal Number =%x",num);

    getch();


}
