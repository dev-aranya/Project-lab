#include<stdio.h>
int main()
{
    int j,i,c=0;
    char s1[30];
    char s2[]="Ovi Debnath";
    for(j=0; s2[j]!='\0'; j++)
    {
        c++;
    }
    for(i=0; i<c; i++)
    {
        s1[i]=s2[i];
    }

    printf("%s",s1);
   // printf("%s",s2);
}
