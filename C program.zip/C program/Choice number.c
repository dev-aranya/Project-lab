#include<stdio.h>
int main()
{
    int x;
    printf("Enter any number = ");
    scanf("%d",&x);
    switch(x)
    {
    default:printf("Choice other than 1 and 2\n");
        break;
    case 1:
        printf("Choice is 1\n");
        break;
    case 2:
        printf("choice is 2\n");
        break;
    }

}
