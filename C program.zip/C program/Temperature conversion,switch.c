#include<stdio.h>
int main()
{
    int choice;
    float temp,convertedtemp;
    printf("Temperature conversion menu\n");
    printf("1. Fahrenheit to celcius\n");
    printf("2. Celcious to Fahernheit\n");
    printf("Enter your choice = ");
    scanf("%d",&choice);
    switch(choice)
    {
    case 1:
        printf("Enter the Fahrenheit = ");
        scanf("%f",&temp);
        convertedtemp=(temp-32)/1.8;
        printf("The temperature in celcious =%f\n",convertedtemp);
        break;

    case 2:
        printf("ENTER THE CELCIOUS = ");
        scanf("%f",&temp);
        convertedtemp=(1.8*temp)+32;
        printf("The temperature in fahrenheit =%f\n",convertedtemp);
        break;

    default :
        {
        printf("No correct option\n");
        }
    }

}
