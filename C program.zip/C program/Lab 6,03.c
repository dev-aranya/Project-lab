#include<stdio.h>
char grade(int a)
{
    switch(a/10)
    {
        case 8 ... 10:
        return 'A';
        break;
        case 7:
        return 'B';
        break;
        case 6:
        return 'C';
        break;
        case 5:
        return 'D';
        break;
        case 4:
        return 'E';
        break;
        default:
        return 'F';
        break;
    }
}
int main()
{
    int n;
    char result;
    printf("enter numbers = ");
    scanf("%d",&n);
    if(n<=100 && n>=0)
    {
        result=grade(n);
        printf("%c",result);
    }
    else
        printf("invalid numbers\n");
}
