#include<stdio.h>
int get_sum(int a[],int c)
{
    int i, sum=0;
    for(i=0; i<c; i++)
    {
        sum= sum+a[i];
    }
    return sum;
}

float get_avg( int a, int c)
{
    float avg;
    avg= (float)a/(float)c;
    return avg;
}

int main()
{
    int n,sum;
    float avg;
    int a[5]={12,10,9,7,14};
    n=5;
    sum= get_sum(a,n);
    avg= get_avg(sum,n);
    printf("Sum: %d\n",sum);
    printf("Average: %.1f\n",avg);
}
