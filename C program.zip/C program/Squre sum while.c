#include<stdio.h>
int main()
{
    int i,n,sum=0;
    printf("Enter Number = ");
    scanf("%d",&n);
    i=1;
    while(i<=n)
    {
        sum=sum+i*i;
        i++;
    }
    printf("sum=%d\n",sum);


}
