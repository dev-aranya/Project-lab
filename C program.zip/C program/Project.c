#include<stdio.h>
void check_odd_even(int x){
if(x%2==0)
    printf("\nThe number is even.\n");
else
    printf("The number is odd.\n");
}
void test_leap_year(int year){
if(year%400==0)
    printf("The year is leap year.\n");
else if(year%4==0 && year%100!=0)
    printf("The year is leap year.\n");
else
    printf("The year is not leap year.\n");
}
void get_prime(int x){
int i,count=0;
for(i=2;i<x;i++){
    if(x%i==0){
        count++;
    }
}
    if(x<2 && x>0)
        count++;
    if(count==0)
        printf("The number is prime.\n");
    else
        printf("The number is not prime.\n");

}

int get_factorial(int x){
int i,fact=1;
for(i=1;i<=x;i++){
    fact=fact*i;
}
printf("Factorial=%d\n",fact);
return fact;
}
int fibonacci(int x){
int first=0,second=1,count=0,fibo;
while(count<x)
{
    if(count<=1)
     fibo=count;
    else{
        fibo=first+second;
        first=second;
         second=fibo;
    }

printf("%d ",fibo);
count++;
}
}
int main()
{
    int m=1;
    while(m==1)
    {
        int n;
        printf("\nChoose any option(1-6)=\n 1.Odd or Even.\n 2.Leap year.\n 3.Prime or not prime.\n 4.Factorial.\n 5.Fibonacci.\n 6.Exit.\n ");
        scanf("%d",&n);
        switch (n){
    case 1:{
        int x;
        printf("Enter any positive number = ");
        scanf("%d",&x);
        check_odd_even(x);
        break;
    }
    case 2:{
        int a;
        printf("Enter any year = ");
        scanf("%d",&a);
        test_leap_year(a);
        break;
    }
    case 3:{
        int a;
        printf("Enter any number = ");
        scanf("%d",&a);
        get_prime(a);
        break;
    }
    case 4:{
        int a;
        printf("Enter any number = ");
        scanf("%d",&a);
        get_factorial(a);
        break;
    }
    case 5:{
        int a;
        printf("Enter any range = ");
        scanf("%d",&a);
        fibonacci(a);
        break;
    }
    case 6:{
        m=2;
        break;
    }
        }


getch ();
}
}
