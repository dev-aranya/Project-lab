#include<stdio.h>
int main()
{
    int num,temp,r,sum=0;
    printf("Enter any number = ");
    scanf("%d",&num);
    temp = num;
    while(temp%10)
    {
        r=temp%10;
        sum=sum+r;
        temp=temp/10;

    }
    printf("Sum of digits =%d\n",sum);

}
