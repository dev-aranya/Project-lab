#include<stdio.h>
#include<string.h>
int main()

{
 char str[50];
 int i=0,l;
 for(i=0;i<str[i];i++)
 {
     l=strlen(str);
      printf("%c",str[l]);
 }
return 0;
}
