#include<stdio.h>
int main()
{
    float r,area;
    printf("Enter any radious = ");
    scanf("%f",&r);
    area=3.1416*r*r;
    printf("The circle area is =%.3f\n",area);


}
