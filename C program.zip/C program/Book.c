#include<stdio.h>
#include<string.h>
struct book{
char name[100];
int page;
float price;
};
int main()
{
int num;
scanf("%d",&num);
fflush(stdin);
struct book b[num];
int i;
for(i=0;i<num;i++)
{
    printf("Enter info of book no =%d\n",i+1);
    gets(b[i].name);
    scanf("%d %f",&b[i].page,&b[i].price);
    fflush(stdin);

}
for(i=0;i<num;i++)
{
    printf("\n book%d = ",i+1);
    printf("%s %d %.2f",b[i].name,b[i].page,b[i].price);
    return 0;
}
}
