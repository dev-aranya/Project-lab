#include<stdio.h>
#include<stdlib.h>
int main()
{
    FILE *f1,*f2;
    int x,y;

    f1=fopen("input.txt","w");
    if(f1==NULL)
    {
        printf("Input File Not Found!");
        exit(0);
    }
    fscanf(f1,"%d %d",&x,&y);

    printf("\n%d + %d = %d",x,y,x+y);

    f2=fopen("out.txt","w");

    fprintf(f2,"\n%d+%d=%d",x,y,x+y);
    fclose(f1);
    fclose(f2);
    return 0;
}
