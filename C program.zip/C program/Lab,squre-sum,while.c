#include<stdio.h>
int main()
{
    int x,n,sum=0;
    printf("Enter any number = ");
    scanf("%d",&n);
    x=1;
    while(x<=n)
    {
        sum=sum+x*x;
        x++;
    }
    printf("SUM=%d\n",sum);
}
