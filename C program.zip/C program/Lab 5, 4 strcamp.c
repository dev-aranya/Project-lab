#include<stdio.h>
int main()
{
    char s1[100];
    gets(s1);
    char s2[100];
    gets(s2);
    int c;
    c=strcmp(s1,s2);
    if(c==0)
    {
        printf("String are same");
    }
    else
        printf("String are not same");
}
