#include<stdio.h>
void pointer(int *p, int x)
{
    int i,sum=0;
    printf("Function elements = ");
    for(i=0;i<x;i++)
    {
        printf("%d ",p[i]);
        sum=sum+p[i];
    }
    printf("\n sum = %d",sum);
}
void main()
{
    int i,num;
    printf("Enter number = ");
    scanf("%d",&num);
    int a[num];
    for(i=0;i<num;i++)
    {
        scanf("%d",&a[i]);
    }
    pointer (a,num);
}
