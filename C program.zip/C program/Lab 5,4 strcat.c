#include<stdio.h>
int main()
{
    char str1[60];
    printf("Input first line = ");
    gets(str1);
    char str2[60];
    printf("Input second line = ");
    gets(str2);
    strcat(str1,str2);
    printf("Str1 =%s",str1);
}
