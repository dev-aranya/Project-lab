#include<stdio.h>
int main()
{
    int n1,n2,add,sub,mul,div,mod;
    printf("Enter two numbers = ");
    scanf("%d %d",&n1,&n2);
    add=n1+n2;
    printf("Addition =%d\n",add);
    sub=n1-n2;
    printf("subtraction =%d\n",sub);
    mul=n1*n2;
    printf("Multiplecation =%d\n",mul);
    div=n1/n2;
    printf("Devision =%d\n",div);
    mod=n1%n2;
    printf("Modulas =%d\n",mod);

    getch ();



}
