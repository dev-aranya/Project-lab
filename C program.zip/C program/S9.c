#include<stdio.h>
int main()
{
    char s1[]="Aranya Debnath Ovi";
    char s2[]="Boss";
    //strcpy(s2,s1);
    strcat(s2,s1);

    printf("%s\n",s1);
    printf("%s\n",s2);
}
