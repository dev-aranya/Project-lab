#include<stdio.h>
int odd_even(int x){
if(x%2==0)
{
    return 1;
}
else {
    return 0;
}

}
int main()
{
    int n,test;
    printf("Enter number = ");
    scanf("%d",&n);
    test=odd_even(n);
    if(test==1)
        printf("\nEven");
    else
        printf("\nodd");
    return 0;
}
