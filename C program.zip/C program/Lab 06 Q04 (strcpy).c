#include<stdio.h>
#include<string.h>
void get_strcpy(char str[])
{
    char cpy[100];
    int len=0;
    len=strlen(str);

    int i=0;
    for(i=0; i<len; i++)
    {
        cpy[i] =str[i];
    }
    printf("The copy string is: %s\n",cpy);
}

int main()
{
    char str[100];
    gets(str);
    get_strcpy(str);
}
