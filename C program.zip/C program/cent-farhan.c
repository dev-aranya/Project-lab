#include<stdio.h>
int main()
{

    float c,f;
    printf("Enter any Centigrate temprature = ");
    scanf("%f",&c);
    f=(1.8*c)+ 32;
    printf("Farhanhite temprature =%.3f",f);

}
