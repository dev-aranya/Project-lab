#include<stdio.h>
int main()
{
    int x;
    printf("Enter any number= ");
    scanf("%d",&x);
    if(x>0){
        printf("positive");
    }
    else if(x<0){
        printf("Negetive");

    }
    else{
        printf("Zero");
    }





}
