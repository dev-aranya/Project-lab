#include<stdio.h>
int main()
{
    int i,n,sum=0;
    printf("Enter num= ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        sum=sum+i;
    }
    printf("The sum=%d\n",sum);

}
