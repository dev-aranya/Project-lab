#include<stdio.h>
#include<math.h>

float squrearea(float side);
float circlearea(float rad);
float trianglearea(float height,float weidth);
float rectanglearea(float a,float b);

int main()
{
    float a=4.0;
    float b=5.0;
    float side=6.00,rad=8.00,height=7.00,weidth=9;

    printf("RectangleArea is =%f\n",rectanglearea(a,b));
    printf("SqureArea =%f\n",squrearea(side));
    printf("CircleArea = %f\n",circlearea(rad));
    printf("Triangle area=%f\n",trianglearea(height,weidth));

    return 0;
}

float squrearea(float side)
{
    return side*side;
}
float circlearea(float rad)
{
    return 3.1416*rad*rad;

}
float trianglearea(float height,float weidth)
{
    return 0.5*height*weidth;
}
float rectanglearea(float a,float b)
{
    return a*b;
}
