#include<stdio.h>   //1*1+2*2+3*3+......+n*n
int main()
{
    int i,n,sum=0;
    printf("Enter any number = ");
    scanf("%d",&n);
    for(i=1;i<=n;i=i+2)
    {
        sum=sum+i*i;
    }
    printf("sum=%d\n",sum);
    getch ();

}
