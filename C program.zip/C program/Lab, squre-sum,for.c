#include<stdio.h>
int main()
{
    int n,x,sum=0;
    printf("Enter any number = ");
    scanf("%d",&n);
    for(x=1;x<=n;x++)
    {
        sum=sum+x*x;
    }
    printf("Sum=%d\n",sum);
}
