#include<stdio.h>
struct book
{
    char book_name[25];
    int book_pages;
    float book_price;

};
int main()
{
    struct book b1,b2,b3;

    printf("Enter the information 1st Book : \n");
    //printf("Enter Book Name = ");
    //scanf("%c",&b1.book_name);
    strcpy(b1.book_name,"First C");
    printf("Enter Book pages number = ");
    scanf("%d",&b1.book_pages);
    printf("Enter Book price = ");
    scanf("%f",&b1.book_price);


    printf("Enter the information 2nd Book : \n");
    //printf("Enter Book Name = ");
    //scanf("%c",&b2.book_name);
    strcpy(b2.book_name,"ANSI C");
    printf("Enter Book pages number = ");
    scanf("%d",&b2.book_pages);
    printf("Enter Book price = ");
    scanf("%f",&b2.book_price);


     printf("Enter the information 3rd Book : \n");
    //printf("Enter Book Name = ");
    //scanf("%c",&b3.book_name);
     strcpy(b3.book_name,"Introduce C");
     printf("Enter Book pages number = ");
     scanf("%d",&b3.book_pages);
     printf("Enter Book price = ");
     scanf("%f",&b3.book_price);



    printf("1st Book  : \n");
    printf("1st Book Name = %s\n",b1.book_name);
    printf("1st Book pages = %d\n",b1.book_pages);
    printf("1st Book Price = %f\n",b1.book_price);

    printf("2nd Book  : \n");
    printf("2nd Book Name = %s\n",b2.book_name);
    printf("2nd Book pages = %d\n",b2.book_pages);
    printf("2nd Book Price = %f\n",b2.book_price);

    printf("3rd Book Name : \n");
    printf("3rd Book Name = %s\n",b3.book_name);
    printf("3rd Book pages = %d\n",b3.book_pages);
    printf("3rd Book Price = %f\n",b3.book_price);

    getch();

}
