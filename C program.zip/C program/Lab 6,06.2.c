#include<stdio.h>
int leap_year(int (x))
{
    if(x%400==0)
    {
        return 1;
    }
    else if(x%4==0 && x%100!=0)
    {
        return 1;
    }
    else {
        return 0;
    }
}
int main()
{
    int y,test;
    printf("Enter year = ");
    scanf("%d",&y);
    test=leap_year(y);
    if(test==1)
        printf("\nLeap year");
    else
        printf("\nNot Leap year");
    return 0;
}
