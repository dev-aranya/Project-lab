#include<stdio.h>
#include<stdlib.h>
int main()
{
    int a[100]={0};
    int n;
    scanf("%d",&n);
    int count=0,x,i;
    while(1)
    {
        x=rand()%100;

        for(i=0;i<100;i++)
        {
            if(x!=a[i])
            {
                a[count]=x;
                count++;
                break;
            }
        }
        if(count==n)
        {
            break;
        }
    }
    for(int i=0;i<n;i++){
    printf("%d ",a[i]);
    }
}
