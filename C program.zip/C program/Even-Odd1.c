#include<stdio.h>
int main()
{

    int x,r;
    printf(" Enter any number= ");
    scanf("%d",&x);
    if(r==0){
        printf("Even");

    }
    else{
        printf("Odd");
    }



}
