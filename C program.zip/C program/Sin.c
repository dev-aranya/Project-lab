#include<stdio.h>
int main()
{
    double x;
    printf("Enter any value= ");
    scanf("%lf",&x);
    double result=sin(x);
    printf("%lf\n",result);

}
