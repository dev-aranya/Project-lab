#include<stdio.h>
int main()
{
   char str1[]="Aranya Debnath ";
   char str2[]="ovi";

   int a=strcmp(str1,str2);

   if(a==0)
   {
       printf("String are equal");
   }
   else
    printf("String are not equal");

}
