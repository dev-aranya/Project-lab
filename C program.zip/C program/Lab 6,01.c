#include<stdio.h>
int maxi(int a,int b);
int mini(int x,int y);
int maxi (int a,int b)
{
    return ((a>b)?a:b);
}
int mini (int x,int y)
{
    return ((x<y)?x:y);
}
int main()
{
    int n1,n2,max,min;
    printf("Enter two numbers  = ");
    scanf("%d %d",&n1,&n2);
    max=maxi(n1,n2);
    min=mini(n1,n2);
    printf("\n%d is maximum number",max);
    printf("\n%d is minimum number",min);
    return 0;
}
