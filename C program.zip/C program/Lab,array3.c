#include<stdio.h>
int main()
{
    int i,n;
    printf("How many number = ");
    scanf("%d",&n);
    int x[n];
    printf("Enter numbers = ");
    for(i=0;i<n;i++)
    {
        scanf("%d",&x[i]);
    }
    int min=x[0];
    for(i=0;i<n;i++)
    {
        if(min>x[i])
            min=x[i];
    }
    printf("Smallest number =%d",min);
}
