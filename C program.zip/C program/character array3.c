#include<stdio.h>
int main()
{
  char ch, str[100];
  int n,i=0,l=0;
  while((ch=getchar())!='\n')
  {
      str[i]=ch;
      i++;

  }
  str[i]='\0';

  for(i=0;i<str[i];i++){
    l++;
  }
  printf("\nString length%d",l);

}


