#include<stdio.h>
int main()
{
    char ch, str[50];
    int i=0,j=0;
    gets(str);
    for(i=0; str[i]; i++)
    {
        ch=str[i];
        if((ch>='A' && ch<='Z') || (ch>='a' && ch<='z') || ch>='0'){
            str[j]=ch;
            j++;
        }
    }
    str[j]='\0';
    printf("String = %s\n",str);

}
