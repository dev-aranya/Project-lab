#include<stdio.h>
int main()
{
    char str[100];
    scanf("%[^\n]",str);
    int i;
    for(i=0;i<str[i];i++)
    {
        printf("%c",str[i]);
    }
}
