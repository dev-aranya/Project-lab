#include<stdio.h>
int main()
{
    int time,y;
    printf("Enter any time = ");
    scanf("%time",&time);
    if(time==10)
    {
        printf("good morning ovi\n");
        printf("walk up\n");
        printf("eat breakfast\n");
        printf("go to versity\n");
        printf("thank you\n");

    }
    else
    {
        printf("bad morning ovi\n");
        printf("sleep again\n");
        printf("thank you\n");

    }


}
