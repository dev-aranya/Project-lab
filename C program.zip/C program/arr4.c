#include<stdio.h>
int main()
{
    int n,i,arr[]={2,3,4,5,6,7,5,10};
    int position=-1;
    printf("Want your search value= ");
    scanf("%d",&n);
    for(i=0;i<8;i++)
    {
        if(n==arr[i])
        {
            position=i+1;
            break;
        }
    }
    if(position==-1)
    {
        printf("Iteam is not found\n",position);
    }
    else
        printf("Iteam is found\n",position);

}
