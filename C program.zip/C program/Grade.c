#include<stdio.h>
int main()
{

    int x;
    scanf("%d",&x);
    switch(x){

case(80-100) :
    printf("A+");
    break;
case(70-79) :
    printf("A");
    break;
    case(60-69) :
    printf("B+");
    break;
case(50-59) :
    printf("B");
    break;
case(40-49) :
    printf("C");
    break;
case(x<40) :
    printf("F");

    }
}
