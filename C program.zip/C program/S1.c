#include<stdio.h>
int main()
{
    char s1[30];
    printf("Enter your name = ");
    gets(s1);



    printf("S1=%s\n",s1);

}
