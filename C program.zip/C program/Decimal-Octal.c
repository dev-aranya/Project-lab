#include<stdio.h>
int main()
{
    int num;
    printf("Decimal Number = ");
    scanf("%d",&num);
    printf("Octal Number = %o",num);

    getch();

}
