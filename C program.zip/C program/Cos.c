#include<stdio.h>
int main()
{
    double x;
    printf("Enter any value = ");
    scanf("%lf",&x);
    double result=cos(x);
    printf("%lf\n",result);

}
