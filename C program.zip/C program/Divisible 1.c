#include<stdio.h>
int main()
{

    int x,r;
    printf("Enter any number = ");
    scanf("%d",&x);
    r=x%5;
    if(r==0){
        printf("X is Divisible by 5");

    }
    if(r==1){
        printf("X is not Divisible by 5");
    }
    if(r==2){
        printf("X is not Divisible by 5");
    }
    if(r==3){
        printf("X is not Divisible by 5");
    }
    if(r==4){
        printf("X is not Divisible by 5");

    }

}
