#include<stdio.h>
int main()
{
    int num[]={10,3,4,2,7,5,9,10};
    int value,position=-1,i;
    printf("Enter the value you want to search: ");
    scanf("%d",&value);
    for(i=0;i<8;i++)
    {
        if(value==num[i])
        {
            position=i+1;
            break;
        }
    }
    if(position==-1)
    {
        printf("Item is not found \n");
    }
    else
        printf("Iteam is found\n");
}
