
#include<stdio.h>
struct stu_info{
   char name[100];
   char id[20];
   float gpa;
};
int main(){
    struct stu_info s1;
    printf("Enter Student name = ");
    gets(s1.name);
    fflush(stdin);
    printf("Enter student ID = ");
    scanf("%s",s1.id);
    printf("Enter GPA = ");
    scanf("%f",&s1.gpa);
    printf("Student name = %s\nStudent ID = %s\nGPA=%.2f\n",s1.name,s1.id,s1.gpa);
    struct stu_info s2;
    fflush(stdin);
    printf("Enter Student name = ");
    gets(s2.name);
    fflush(stdin);
    printf("Enter student ID = ");
    scanf("%s",s2.id);
    printf("Enter GPA = ");
    scanf("%f",&s2.gpa);
    printf("Student name = %s\nStudent ID = %s\nGPA=%.2f\n",s2.name,s2.id,s2.gpa);
}
