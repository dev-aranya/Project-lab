#include<stdio.h>
int main()
{
    char op;
    printf("enter an operator(+,-,*,/,%) :");
    scanf("%c",&op);
    int a,b;
    printf(" enter two int numbers= ");
    scanf("%d %d",&a,&b);
    switch(op){
case '+':
    printf("addition=%d",a+b);
    break;
case '-':
    printf("subtraction=%d",a-b);
    break;
case '*':
    printf("multiplecation=%d",a*b);
    break;
case '/':
    printf("devision=%d",a/b);
    break;
case '%':
    printf("modulas=%d",a%b);
    break;
    }


}
