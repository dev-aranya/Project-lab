#include<stdio.h>
int main()
{

    int x,r;
    printf("Enter any number = ");
    scanf("%d",&x);
    r=x%5;
    if(r==0){
        printf("X is Divisible by 5");
    }
    else{
        printf("X is not Divisible by 5");

    }



}
