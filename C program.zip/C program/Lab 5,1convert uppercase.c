#include<stdio.h>
int main()
{
    char ch,str[100];
    int i;
    gets(str);
    for(i=0;str[i];i++)
    {
        ch=str[i];
        if(ch>='A' && ch<='Z' || ch>='a' && ch<='z')
        {
            str[i]=ch-32;
        }
    }
    printf("%s",str);
}
