#include<stdio.h>
int main()
{
   char str[50],ch;
   int i,vowel,consonant,digit,word,other;
   printf("Enter your name = ");
   gets(str);
   i=vowel=consonant=digit=word=other=0;
   while((ch=str[i])!='\0')
   {
       if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' ||
          ch=='A' || ch=='E' || ch=='I' || ch=='O' || ch=='U')

          vowel++;
          else if((ch>='a' && ch<='z') || (ch>='A'  && ch<='Z'))
            consonant++;
          else if(ch>='0' && ch<='9')
            digit++;
            else if(ch==' ')
                word++;
            else
                other++;

            i++;


   }
   word++;
   printf("Vowel=%d\n",vowel);
    printf("Consonant=%d\n",consonant);
     printf("digit=%d\n",digit);
      printf("word=%d\n",word);
       printf("Others=%d\n",other);


    getch();
}
