#include<stdio.h>
void main()
{
    int n=6,r=2;
    int np,nc;
    np=npr(n,r);
    nc=ncr(n,r);
    printf("\n npr=%d",np);
    printf("\n ncr=%d",nc);
}

int factorial(n)
{
    int i,fact=1;
    for(i=1;i<=n;i++)
    {
        fact=fact*i;
    }
     return fact;
}
int npr(int n,int r)
{
    return factorial(n)/factorial(n-r);
}
int ncr(int n,int r)
{
    return npr(n,r)/factorial(r);
}
