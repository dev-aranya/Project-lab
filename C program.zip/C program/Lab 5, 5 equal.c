
#include<stdio.h>
int main()
{
    char s1[]="Aranya Debnath";
    char s2[]="Aranya Debnath";
    int c;
    c=strcmp(s1,s2);
    if(c==0){
        printf("Any of them =%s\n",s1);
    }
    else
    {
        strcat(s1,s2);
        printf("Combined =%s\n",s1);
    }

}
