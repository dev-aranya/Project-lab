#include<stdio.h>
int factorial(int n)
{
    int i,fact=1;
    for(i=1;i<=n;i++)
    {
        fact=fact*i;
    }
}
int main()
{
    int x,result;
    printf("Enter any number = ");
    scanf("%d",&x);
    result=factorial(x);
    printf("Factorial=%d\n",result);
    return 0;
}
