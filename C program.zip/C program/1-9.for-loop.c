#include<stdio.h>
int main()
{
  int i;
  for(i=2; i<=50; i++)
        printf("%d\n",i);


}
