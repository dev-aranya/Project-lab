#include<stdio.h>
int main()
{
   int x,y;
   printf("Enter x and y = ");
   scanf("%d %d",&x,&y);
   double result=pow(x,y);
   printf("The result=%.2lf\n",result);

}
