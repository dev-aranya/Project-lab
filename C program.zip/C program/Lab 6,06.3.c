#include<stdio.h>
int prime(int x)
{
    int i,count=0;
    for(i=2;i<x;i++)
    {
        if(x%2==0)
        {
            count++;
            break;
        }

    }
    return 0;
}
int main()
{
    int num,count,test;
    printf("Enter any number = ");
    scanf("%d",&num);
    test=prime(num);
    if(count==0)
        printf("Prime number\n");
    else
        printf("Not prime\n");
    return 0;
}
