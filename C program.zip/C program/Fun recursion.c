#include<stdio.h>

void printhlw(int count);

int main()
{
    printhlw(10);
    return 0;
}
void printhlw(int count)
{
    if(count==0)
    {
        return;
    }
    printf("Hello world\n");
    printhlw(count-1);
}
