#include<stdio.h>
int main()
{

    int num;
    printf("please enter an integer number=");
    scanf("%d",&num);
    printf("You have pressed = %d\n",num);
    return 0;


}
