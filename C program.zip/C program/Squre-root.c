#include<stdio.h>
int main()
{
    int x;
    printf("Enter any number = ");
    scanf("%d",&x);
    double result = sqrt(x);
    printf("%.2lf\n",result);

}
