#include<stdio.h>
int get_length(char x[]){
int i=0;
for(i;x[i];i++)
    return i;
}
int main(){
char str[50];
printf("Input array = ");
gets(str);
int y=get_length(str);
printf("\n Length is =%d",y);
return 0;
}
