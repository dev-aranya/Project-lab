#include<stdio.h>
int main()
{
    int a[]={10,20,50,-5,0,8,7};
    int x=0,i;
    for( i=0;i<=7;i++)
    {
        if(x==a[i])
        {
            break;
        }

    }
    if(i<7)
    {
        printf("Found");
    }
    else
    {
        printf("Not found");
    }
}
