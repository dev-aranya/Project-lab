#include<stdio.h> //1+2+3+.....+N
int main()
{
    int n,sum=0,i;
    printf("Enter the last num of the series = ");
    scanf("%d",&n);
    printf("1+3+5+.....+%d",n);
    for(i=1;i<=n;i=i+2)
    {
        sum=sum+i;
    }
    printf("=%d\n",sum);

}
