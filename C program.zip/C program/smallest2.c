#include<stdio.h>
int main()
{
    int n1,n2;
    printf("Enter two num = ");
    scanf("%d %d",&n1,&n2);
    if(n1<n2)
    {
        printf("Small=%d\n",n1);

    }
    else if(n1>n2)
    {
        printf("Small=%d\n",n2);

    }
    else
    {
        printf("number are equal\n");

    }
}
