#include<stdio.h>          //2*4*6*8*......*n
int main()
{
   int i,n,result=1;
   printf("Enter any num = ");
   scanf("%d",&n);
   for(i=2;i<=n;i=i+2)
   {
       result=result*i;
   }
   printf("Result=%d\n",result);
   getch ();


}
