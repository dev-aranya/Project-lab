#include<stdio.h>
int main()
{
    char ch,str[100];
    int capital,small,digit,i;
    i=capital=small=digit=0;

    printf("Enter a string = ");
    gets(str);
    while((ch=str[i])!='\0')
    {
        if(ch>=65 && ch<=90)
            capital++;
        else if (ch>=97 && ch<=122)
            small++;
        else if(ch>=48 && ch<=57)
            digit++;
        i++;
    }
    printf("Number of capita letter =%d\n",capital);
     printf("Number of capita small =%d\n",small);
      printf("Number of capita digit =%d\n",digit);
}
