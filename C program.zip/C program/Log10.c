#include<stdio.h>
int main()
{
    double x;
    printf("Enter any value= ");
    scanf("%lf",&x);
    double result=log10(x);
    printf("%lf\n",result);

}
