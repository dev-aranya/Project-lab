#include<stdio.h>
int main()
{

    float a,b,area;
    printf("Enter the values = ");
    scanf("%f %f",&a,&b);
    area=a*b;
    printf("Retangular area is =%.3f\n",area);

    getch ();


}
