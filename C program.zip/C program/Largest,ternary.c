#include<stdio.h>
int main()
{
    int n1,n2,large;
    printf("Enter two numbers = ");
    scanf("%d %d",&n1,n2);
    large =(n1>n2)?  n1:n2;
    printf("largest number =%d\n",large);

    }
