#include<stdio.h>
int main()
{
    char str[100];
    int length;
    printf("Enter your name = ");
    gets(str);
    int i=0;
    while(str[i])
    {
        i++;
    }
    length=i;
    printf("Length =%d\n",length);
}
