#include<stdio.h>
int main()
{
    char str[]= " ";
    printf("enter name = ");
    gets(str);
    strrev(str);
    printf("Reverse=%s\n",str);

}
