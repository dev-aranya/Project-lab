#include<stdio.h>
int main()
{
  int n,i,y,sum=0;
  printf("Enter Number= ");
  scanf("%d",&n);
  for(i=1;i<=n;i++)
  {
      y=i*i;
      sum=sum+y;
  }
  printf("sum=%d",sum);

}
