#include<stdio.h>
int main()
{
    int x,n,fact=1;
    printf("Enter any number = ");
    scanf("%d",&n);
    for(x=1;x<=n;x++)
    {
        fact=fact*x;
    }
    printf("Factorial=%d\n",fact);
}
