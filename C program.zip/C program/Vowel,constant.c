#include<stdio.h>
int main()
{

    char ch;
    printf("Enter any letter = ");
    scanf("%c",&ch);
    if(ch=='a')

        printf("vowel\n");
    else if(ch=='e')
        printf("vowel\n");
    else if(ch=='i')
        printf("vowel\n");
    else if(ch=='o')
        printf("vowel\n");
    else if(ch=='u')
        printf("vowel\n");

    else
    {
        printf("consonant\n");
    }

}
