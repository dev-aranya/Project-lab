#include<stdio.h>
int main()
{
    int n,i,num[20],sum=0;
    printf("how many numbers= ");
    scanf("%d",&n);
    for(i=1;i<n;i++)
    {
        scanf("%d",&num[i]);

    }
      printf("%d\n",num[3]);
      for(i=0;i<n;i++)
      {
          sum=sum+num[i];
      }
      printf("The sum =%d\n",sum);
      printf("The avg=%.2f\n",(float)sum/n);

}
