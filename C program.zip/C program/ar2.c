#include<stdio.h>
int main()
{
    int i,n,arr[40],min,max;
    printf("How many number = ");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    min=arr[0];
    max=arr[0];
    for(i=0;i<n;i++)
    {
        if(max<arr[i])
            max=arr[i];
    }
    for(i=0;i<n;i++)
    {
        if(min>arr[i])
            min=arr[i];
    }
    printf("Maximum= %d\n",max);
    printf("Minimum = %d\n",min);
}
