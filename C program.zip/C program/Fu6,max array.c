#include<stdio.h>
void maxi(int x[])
{
    int i;
    int max=x[0];
    for (i=0;i<8;i++)
    {
        if(max<x[i])
            max =x[i];
    }
    printf("Maximum=%d\n",max);
}
int main()
{
    int num[]={2,3,4,5,6,7,3,1};
    maxi(num);
}
