#include<stdio.h>
int main()
{
    float C,F;
    printf("Enter any farhanhite tem = ");
    scanf("%f",&F);
    C=5.0/9*(F-32);
    printf("Centigrate tem =%.2f\n",C);


}
