#include<stdio.h>
int main()
{
    char s1[30];
    printf("Enter Your name = ");
    gets(s1);
    printf("%s\n",s1);
    int i=0,len=0;
    while(s1[i]!='\0')
    {
        printf("%c\n",s1[i]);
        i++;
        len++;
    }
    printf("Length =%d",len);
    //len = strlen(s1);
    //printf("Length=%d\n",len);
}
