#include<stdio.h>
int main()
{
    char ch,s1[50],s2[40];
    printf("Enter string = ");
    gets(s1);
    int i,capital,small,digit;
    i=capital=small=digit=0;
    while((ch=s1[i])!='\0')
    {
        if(ch>=65 && ch<=90)
            capital++;
        else if(ch>=97 && ch<=122)
            small++;
        else if(ch>=48 && ch<=57)
            digit++;
        i++;
    }
    printf("Number of capital= %d\n",capital);
    printf("Number of Small = %d\n",small);
    printf("Number of Digit = %d\n",digit);

}
