#include<stdio.h>
int main()
{

    int x,y,z;
    printf("Enter three numbers = ");
    scanf("%d %d %d",&x,&y,&z);
    if(x<y){
        if(x<z)
            printf("%d is smallest",x);
        else
            printf("%d is smallest",z);

    }
    else {
        if(y<z)
            printf("%d is smallest",y);
        else
            printf("%d is smallest",z);
    }
}
