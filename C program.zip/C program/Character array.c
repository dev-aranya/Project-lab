#include<stdio.h>
int main()
{
    char str [14]={'A','R','A','N','Y','A','D','E','B','N','A','T','H'};
    int n=14,i;
    for(i=0;i<n-1;i++)
    {
        printf("%c",str[i]);
    }
}
