#include<stdio.h>
int main()
{
    char str[]="Aranya Debnath Ovi";
    strrev(str);

    printf("str = %s\n",str);

}
