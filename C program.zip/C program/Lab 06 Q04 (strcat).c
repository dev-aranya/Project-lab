#include<stdio.h>
#include<string.h>
void get_strcat(char str1[], char str2[])
{
    char str_cat[200];
    int len1=0,len2=0;
    len1=strlen(str1);
    len2=strlen(str2);
    int i,j;

    for(i=0,j=0; i<len1; i++,j++)
    {
        str_cat[j]=str1[i];
    }
    for(i=0; i<len2; i++,j++)
    {
        str_cat[j]=str2[i];
    }

    str_cat[j]='\0';
    printf("The  concatenation string is=%s",str_cat);

}

int main()
{
    char str1[100],str2[100];
    gets(str1);
    gets(str2);
    get_strcat(str1, str2);
}
