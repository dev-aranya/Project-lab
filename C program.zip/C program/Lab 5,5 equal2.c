
#include<stdio.h>
int main()
{
    char s1[50],s2[50];
    printf("Enter 1st line = ");
    gets(s1);
    printf("Enter 2nd line = ");
    gets(s2);
    int c;
    c=strcmp(s1,s2);
    if(c==0)
    {
        printf("any of them=%s",s1);

    }
    else{
    strcat(s1,s2);
        printf("Combined =%s",s1);

    }
}
