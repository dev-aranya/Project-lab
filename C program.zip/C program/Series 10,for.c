#include<stdio.h>      //1*3*5*7*9*........*n
int main()
{
    int i,n,result=1;
    printf("enter any number = ");
    scanf("%d",&n);
    for(i=1;i<=n;i=i+2)
    {
        result=result*i;
    }
    printf("Result =%d\n",result);
    getch ();

}
