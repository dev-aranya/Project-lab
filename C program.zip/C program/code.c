
#include <stdio.h>

int main() {

    int x,y,result;
  printf(" Enter 2 integers = ");
  scanf("%d %d",&x,&y);
   result=7-x-y;
   printf("%d\n",result);

	return 0;
}
