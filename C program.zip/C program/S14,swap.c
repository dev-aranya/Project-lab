#include<stdio.h>
int main()
{
    char s1[50]="Aranya Debnath";
    char s2[30]="ovi deb nath";
    char temp[20];

    strcpy(temp,s1);
    strcpy(s1,s2);
    strcpy(s2,temp);

    printf("s1=%s\n",s1);
    printf("S2=%s\n",s2);
}
