#include<stdio.h>
int main()
{
    int n;
    printf("Enter any ASCII value = ");
    scanf("%d",&n);
    printf("The AScII character is = %c",n);
    return 0;

}
