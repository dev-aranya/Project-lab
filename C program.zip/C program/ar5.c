#include<stdio.h>
int main()
{
    int n,i,ar1[50],ar2[50];
    printf("How many number = ");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&ar1[i]);
    }
    printf("Array1=  ");
    for(i=0;i<n;i++)
    {
        printf("%d ",ar1[i]);
    }
    for(i=0;i<n;i++)
    {
        ar2[i]=ar1[i];
    }
    printf("\nArray2=  ");
    for(i=0;i<n;i++)
    {
        printf("%d ",ar2[i]);
    }
}
