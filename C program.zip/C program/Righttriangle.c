#include<stdio.h>
int main(){

int a,b,c;
printf("enter 3 int numbers = ");
scanf("%d %d %d",&a,&b,&c);
if(((a*a)+(b*b)==(c*c)) || ((a*a)+(c*c)==(b*b))||
 ((c*c)+(b*b)==(a*a)))
{
    printf("right-angle triangle");

}
else{
 printf("not right-angle triangle");

}
}
