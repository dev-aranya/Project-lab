#include<stdio.h>
int main()
{
    int n1,n2;
    printf("Enter two numbers = ");
    scanf("%d %d",&n1,&n2);
    if(n1>n2)
    {
        printf("Large=%d\n",n1);

    }
    else if(n1<n2)
    {
        printf("Large=%d",n2);

    }
        else
        {
            printf("Number are Equal\n");
        }




}
