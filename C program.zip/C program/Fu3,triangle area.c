#include<stdio.h>
// double trianglearea(double b,double h);
  double trianglearea(double b,double h)
{
    return 0.5*b*h;
}


int main()
{
    double base,height;
    printf("Enter base & height = ");
    scanf("%lf %lf",&base,&height);
    double area=trianglearea(base,height);
    printf("Area = %.2lf\n",area );
}

