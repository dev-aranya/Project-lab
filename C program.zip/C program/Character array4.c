#include<stdio.h>
int main()
{
    char str[]="Aranya debnath";
    int i;
    for(i=0;str[i];i++)
    {

        printf("%c",str[i]);

    }

}
