#include<stdio.h>
int main()
{
    int i,n,sum=0;
    float a;
    printf("How many numbers = ");
    scanf("%d",&n);
    int arr[n];
    printf("enter numbers = ");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
        sum=sum+arr[i];
    }
    printf("sum=%d\n",sum);
    a=(float)sum/n;
    printf("Avg=%.2f\n",a);
    printf("Larger any elements = ");
    for(i=0;i<n;i++)
    {
        if(a<arr[i]){
            printf("%d ",arr[i]);
        }
    }
}
