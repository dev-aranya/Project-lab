#include<stdio.h>
int main()
{

    int num;
    printf("Octal Number = ");
    scanf("%d",&num);
    printf("Decimal Number =%d",num);

    getch();

}
