#include<stdio.h>
void namaste();
void bonjur();

int main()
{
    printf("Enter f for french & i for indian : ");
    char ch;
    scanf("%c",&ch);

    if(ch=='i')
    {
        namaste();
    }
    else {
        bonjur();
    }

    return 0;
}
void namaste(){

printf("Namaste\n");

}
void bonjur()
{
    printf("Bonjur\n");
}
