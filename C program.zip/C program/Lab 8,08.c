
#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *file;
    int n;

    file = fopen("8_inputFile.txt", "r");
    if (file == NULL)
    {
        printf("Unable to open the file.\n");
        exit(0);
    }

    printf("Enter the value of n: ");
    scanf("%d", &n);

    fseek(file, -n, 2);
    char LastN[n + 1];

    for (int i = 0; i < n; i++)
    {
        fscanf(file, "%c", &LastN[i]);
    }

    LastN[n] = '\0';
    printf("Last %d characters: %s\n", n, LastN);
    rewind(file);

    char FirstN[n + 1];

    for (int i = 0; i < n; i++)
    {
        fscanf(file, "%c", &FirstN[i]);
    }

    FirstN[n] = '\0';
    printf("First %d characters: %s\n", n, FirstN);

    fclose(file);

    return 0;
}
