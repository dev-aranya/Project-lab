#include<stdio.h>
int main()
{
    int n1,n2,sum;
    float avg;
    printf("Enter two numbers = ");
    scanf("%d %d",&n1,&n2);
    sum=n1+n2;
    printf("SUM =%d\n",sum);
    avg=(float)sum/2; // type casting
    printf("AVG=%.2f\n",avg);

getch();


}
