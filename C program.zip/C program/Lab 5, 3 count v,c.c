#include<stdio.h>
int main()
{
    char ch,str[100];
    int i,vowel,consonant;
    vowel=0,consonant=0;
    gets(str);
    for(i=0;str[i];i++)
    {
        ch=str[i];
        if(ch>='A' && ch<='Z' || ch>='a' && ch<='z')
        {
            if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' ||
               ch=='A' || ch=='E' || ch=='I' || ch=='O' || ch=='U')
                vowel++;
            else
                consonant++;
        }
    }
    printf("Vowel= %d\n",vowel);
    printf("Consonant =%d\n",consonant);
}
