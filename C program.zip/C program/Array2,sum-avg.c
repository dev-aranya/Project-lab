#include<stdio.h>
#include<stdlib.h>
int main()
{
    int n,sum=0,x[n],i;
    printf("Enter any number = ");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        x[i]=rand()%11;
        printf("%d ",x[i]);
        sum=sum+x[i];
    }
    printf("Sum=%d\n",sum);
    printf("Avgrage =%d\n",(float)sum/n);
}
