#include<stdio.h>
#include<stdlib.h>
int main()
{
    int i,x[100],n ;
    printf("Enter any numbers = ");
    scanf("%d",&n);
    for(i=0;i<100;i++)
    {
        x[i]=rand()%11;
       printf("%d ",x[i]);
    }

}
