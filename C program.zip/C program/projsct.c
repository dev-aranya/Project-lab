#include<stdio.h>
void check_odd_even(int x){
if(x%2==0){
    printf("The given number is Even.");
}
else{
    printf("The given number is Odd.");
}
}
void check_leapyear(int x){
if((x%100==0)&&(x%400==0)){
    printf("Leap year");}
else if((x%100!=0)&&(x%4==0)){
    printf("Leap year");
}
else{
    printf("Not Leap year");
}
}
void get_prime(int x){
int i,c=0;
for(i=2;i<x;i++){
    if(x%i==0){
        c=c+1;
    }
    }
    if((x<2)&&(x>0)){
        c=c+1;
    }
    if(c==0){
    printf("Prime");
    }
    else{
    printf("Not prime");
    }
    }
int get_fact(int x){
int i,f=1;
for(i=1;i<=x;i++){
    f=f*i;
}
return f;
}
void fibo(int x){
int a=0,b=1,tam;
printf("%d %d",a,b);
for(int i=1;i<=(x-2);i++){
    tam=a+b;
    a=b;
    b=tam;
    printf(" %d",tam);
}
}
int main(){
    printf("*_WELCOME TO THE PROGRAM_***\n");
    int z=1;
    while(z==1){
int a;
printf("\n Choose any option(1-6):\n 1.Odd or even\n 2.Leap year\n 3.Prime or not prime\n 4.Factorial\n 5.Fibonacci series\n 6.Exit\n");
scanf("%d",&a);
switch(a){
case 1 :{
    int b;
    printf("For checking odd or even, input a number=");
    scanf("%d",&b);
    check_odd_even(b);
    break;
}
case 2 :{
    int b;
    printf("For checking leap year, input a year=");
    scanf("%d",&b);
    check_leapyear(b);
    break;
}
case 3 :{
        int b;
    printf("For checking prime or not, input a number=");
    scanf("%d",&b);
    get_prime(b);
    break;
}
case 4 :{
    int b;
    printf("To get factorial, input a number=");
    scanf("%d",&b);
    int c=get_fact(b);
    printf("Factorial is= %d",c);
    break;
}
case 5 :{
    int b;
    printf("To get fibonacci series, input the length=");
    scanf("%d",&b);
    fibo(b);
    break;
}
case 6 :{
    int a=0;
    while (a==0){
    int b;
    printf("\n Press 1 to cancel exiting.\n Press 2 to conform exiting.\n\n");
    scanf("%d",&b);
    if(b==1){
    a=1;
    }
    else if(b==2){
        z=2;
        a=1;
    }
    else{
        printf("\n *You have selected invalid option.\n *please select the valid one.\n\n");
}
}
break;
}
default:{
        printf("\n *You have selected invalid option.\n *please select the valid one.\n\n");
        continue;
}
}
}
printf("\n Press Enter to continue.\n");
getch();
printf("\n\n***_THANK YOU & GOOD BYE_*");
}
