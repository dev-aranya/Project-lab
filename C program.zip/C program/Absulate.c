#include<stdio.h>
int main()
{
int x;
printf("Enter any number = ");
scanf("%d",&x);
 int result=abs(x);
 printf("Absulate number=%d\n",result);


}
