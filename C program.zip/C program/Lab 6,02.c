#include<stdio.h>
int get_sum(int x[],int y)
{
    int i,sum=0;
    for(i=0;i<y;i++)
    {
        sum=sum+x[i];
    }
    return sum;
}
float get_avg(int a,int b)
{
    float avg;
    avg=(float)a/b;
    return avg;
}
int main()
{
    int a[10],i,n,sum;
    float avg;
    printf("Enter 6 numbers = ");
    for(i=0;i<6;i++)
    {
        scanf("%d",&a[i]);
    }
    n=6;
    sum=get_sum(a,n);
    avg=get_avg(sum,n);
    printf("Sum=%d\n",sum);
    printf("Average=%.2f\n",avg);
}
