#include<stdio.h>
int main()
{
    int i,j,arr[6]={2,4,3,8,7,5,},temp;
    for(i=0;i<6;i++)
    {
        for(j=i+1;j<6;j++)
        {
            if(arr[i]<arr[j])
            {
                temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;

            }
        }
    }
    for(i=0;i<6;i++)
    {
        printf("%d",arr[i]);
    }
}
