#include<stdio.h>
int main(){
    printf("Ta ta Bye Bye");
}
