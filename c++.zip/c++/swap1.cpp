// #include<bits/stdc++.h>
// using namespace std;
// // call by value
// void swao(int *a,int *b){
//     int temp=*a;
//     *a=*b;
//     *b=temp;
// }
// int main(){
//     int x,y;
//     cin>>x>>y;
//     swap(x,y);
//     cout<<"X ="<<x<<endl;
//     cout<<"Y ="<<y<<endl;
// }


#include<bits/stdc++.h>
using namespace std;
// call by reference
void swap(int &a,int &b){
    int temp=a;
    a=b;
    b=temp;
}

int main(){
    int x,y;
    cin>>x>>y;
    swap(x,y);
    cout<<"x ="<<x<<endl;
    cout<<"Y ="<<y<<endl;
}