// #include<bits/stdc++.h>
// using namespace std;

// int sum(int n){
//     if(n==0){
//         return 0;
//     }
//     int presum=sum(n-1);
//     return n + presum;
// }
// int main(){
//     int a;
//     cin>>a;
//     cout<<sum(a)<<endl;
// }



// #include<bits/stdc++.h>
// using namespace std;

// int power(int n,int p){

//     if(p==0){
//         return 1;
//     }
//     int prepower=power(n,p-1);
//     return n*prepower;
// }

// int main(){
//     int x,y;
//     cin>>x>>y;
//     cout<<power(x,y)<<endl;
// }



// #include<bits/stdc++.h>
// using namespace std;

// int factorial(int n){
//     if(n==0){
//         return 1;
//     }
//  int fact= factorial(n-1);
//  return  n*fact;
// }

// int main(){
//     int a;
//     cin >>a;
//     cout<<factorial(a)<<endl;
// }


// #include<bits/stdc++.h>
// using namespace std;

// int fibo(int n){
//     if(n==0 || n==1){
//         return n;
//     }
//     return fibo(n-1) + fibo(n-2);
// }

// int main(){
//     int n;
//     cin>>n;
//     cout<<fibo(n)<<endl;
// }



// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//     int num,first=0,second=1,fibo;
//     cin>>num;
//     for(int i=0;i<num;i++){
//         cout<<first<<" ";
//         fibo=first+second;
//         first=second;
//         second=fibo;
//     }
// }


// array sort kina??
// #include<bits/stdc++.h>
// using namespace std;

// bool sorted(int arr[],int n){
//     if(n==1){
//         return true;
//     }
//     bool restarray = sorted(arr+1,n-1);
//     return (arr[0]<arr[1] && restarray);
// }

// int main(){
//     // int arr[]={34, 5, 7,9};
//     int arr[]={2,3,4,5};
//     cout<<sorted(arr,4)<<endl;
// }



// #include<bits/stdc++.h>
// using namespace std;

// int fun(int n){
//     if(n==1)
//     return 1;
//     else 
//     return n+ fun(n-1);
// }

// int main(){
//     int n;
//     cin>>n;
//     cout<<fun(n)<<endl;
// }



// #include<bits/stdc++.h>
// using namespace std;

// int fun(int n){
//     if(n==0)
//     return 1;
//     else 
//     return 7+fun(n-2);
// }

// int main(){
//     cout<<fun(4)<<endl;
// }



#include<bits/stdc++.h>
using namespace std;

void fun(int n){
    if(n==0){
        return;
    }
        fun(n-1);
        cout<<n<<" ";
    
}

int main(){
    fun(8);
}