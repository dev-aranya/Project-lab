#include<bits/stdc++.h>
using namespace std;
int main(){
    int T;cin>>T;
    while(T--){
        int x,y;cin>>x>>y;
        int a=x%y;
        cout<<a<<endl;
    }
}