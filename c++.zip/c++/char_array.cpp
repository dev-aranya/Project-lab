#include<bits/stdc++.h>
using namespace std;
int main(){
    /*
 char arr[50]="Aranya Debnath";
 int i=0;
 while(arr[i]!='\0'){
    cout<<arr[i]<<endl;
    i++;
 }
 */
char arr[50];
cin.getline(arr,50);

cout<<arr;
 return 0;
}