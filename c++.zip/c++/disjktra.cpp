#include<bits/stdc++.h>
using namespace std;

typedef pair<int, int> pii; // (distance, node)

void dijkstra(int n, vector<vector<pii>>& adj, int source) {
    vector<int> dist(n, INT_MAX);
    dist[source] = 0;

    // Min-heap based on distance
    priority_queue<pii, vector<pii>, greater<pii>> pq;
    pq.push({0, source});

    while (!pq.empty()) {
        int u = pq.top().second;
        int d_u = pq.top().first;
        pq.pop();

        // Skip if a shorter path to u has already been found
        if (d_u > dist[u]) continue;

        for (auto edge : adj[u]) {
            int v = edge.first;
            int weight = edge.second;

            if (dist[u] + weight < dist[v]) {
                dist[v] = dist[u] + weight;
                pq.push({dist[v], v});
            }
        }
    }

    // Print the shortest distances
    cout << "Shortest distances from source " << source << ":\n";
    for (int i = 0; i < n; i++) {
        if (dist[i] == INT_MAX)
            cout << "Node " << i << ": Unreachable" << endl;
        else
            cout << "Node " << i << ": " << dist[i] << endl;
    }
}

int main() {
    int n, e;
    cout << "Enter number of nodes and edges: ";
    cin >> n >> e;

    vector<vector<pii>> adj(n);

    cout << "Enter edges (u v weight):\n";
    for (int i = 0; i < e; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        adj[u].push_back({v, w});
        adj[v].push_back({u, w}); // Remove this line for directed graph
    }

    int source;
    cout << "Enter source node: ";
    cin >> source;

    dijkstra(n, adj, source);

    return 0;
}
