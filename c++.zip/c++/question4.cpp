#include<bits/stdc++.h>
using namespace std;
class Example{
    private:
    int X,Y;
    public:
    Example(){
        X=10;
        Y=20;
    }
    Example(int x,int y){
        X=x;
        Y=y;
    }
    void Display(){
        cout<<"Value after initialization:"<<endl;
        cout<<"X:"<<X<<endl;
        cout<<"Y:"<<Y<<endl;
    }
};
int main(){
    Example ob;
    Example ob1(30,40);
    cout<<"Default constructor:"<<endl;
    ob.Display();
    cout<<"Parameterized constructor:"<<endl;
    ob1.Display();
    return 0;
}