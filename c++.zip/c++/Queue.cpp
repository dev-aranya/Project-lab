#include<bits/stdc++.h>
using namespace std;
int main(){
     queue<int>q,q1;
    q.push(1);
    q.push(2);
    q.push(3);

    q1.emplace(4);
    q1.emplace(5);
    q1.emplace(6);
    // int sz=q.size();
    // cout<<sz<<endl;
    // if(q.empty())cout<<"Empty"<<endl;
    // // else cout<<"Not Empty";
    // cout<<q.front()<<endl;
    // cout<<q.back()<<endl;
    // q.pop();
    // cout<<q.front()<<endl;
    q.swap(q1);

    //while(!q.empty())
    while(q.size()>0){
        cout<<q.front()<<" ";
        q.pop();
    }
}