#include<bits/stdc++.h>
using namespace std;
int main(){
    int n,sum=0;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
        sum=sum+arr[i];
    }
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
       
    }
        cout<<endl;
          cout<<sum<<endl;
          float avg=sum*1.0/n;
          cout<<avg<<endl;
}