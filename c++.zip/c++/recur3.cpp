// #include<bits/stdc++.h>
// using namespace std;

// void sub_seq(string s,string ans){
//     if(s.length()==0){
//         cout<<ans<<endl;
//         return;
//     }
//     char ch=s[0];
//     int code=ch;
//     string ros=s.substr(1);

//     sub_seq(ros,ans);
//     sub_seq(ros,ans+ch);
//     sub_seq(ros,ans + to_string(code));
// }

// int main(){
//     sub_seq("AB","");
//     return 0;
// }

//print number n to 0
#include<bits/stdc++.h>
using namespace std;
 void print_num(int n){
    if(n==0){
        return 0;
    }
    
    int ans = print_num(n-1);
    return ans;
 }

 int main(){
    print_num(5);
 }