#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    bool a=0;
    for(int i=2;i<sqrt(n);i++){
        if(n%i==0){
            cout<<"Not Prime"<<endl;
            a=1;
            break;
        }
    }
    if(a==0){
        cout<<"Prime";
    }
}