#include<bits/stdc++.h>
using namespace std;
void foo(int arr[],int length){
    int sum=0;
    int product=31;
    for(int i=0;i<length;i++){
        sum+=arr[i];
    }
    cout<<sum;
    for(int i=0;i<length;i++){
        product*=arr[i];
    }
    cout<<product;
}

int main(){
    int arr[]={3,5,66};
     foo(arr,3);
    return 0;
}