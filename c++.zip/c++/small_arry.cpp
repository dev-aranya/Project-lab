#include<iostream>
using namespace std;
int main(){
    cout<<"I am aranya devnath ovi"<<endl;
    cout<<"Sunny Lion is my girl friend"<<endl;
}