// #include<bits/stdc++.h>
// using namespace std;
// int sum(int n){
//     if(n==0)
//     {
//         return 0;
//     }
//     int prevsum=sum(n-1);
//     return n+prevsum;
// }

// int main()
// {
//     int x;
//     cin>>x;
//     cout<<sum(x)<<endl;
// }



// #include<bits/stdc++.h>
// using namespace std;
// int power(int n,int p){
//     if(p==0){
//         return 1;
//     }
//     int prevpower=power(n,p-1);
//     return  n*prevpower;

// }

// int main(){
//     int x,y;
//     cin>>x>>y;
//     cout<<power(x,y)<<endl;
// }


#include<bits/stdc++.h>
using namespace std;
int factorial(int n){
    if(n==0){
        return 1;
    }
    // int fact=factorial(n-1);
    // return n*fact;
   return n*factorial(n-1);
}

int main(){
    int x;
    cin>>x;
    cout<<factorial(x)<<endl;
}


// #include<bits/stdc++.h>
// using namespace std;
// int fibo(int n){
//     if(n==0 || n==1){
//         return n;
//     }
//     return fibo(n-1)+fibo(n-2);
// }
// int main(){
//     int x;
//     cin>>x;
//     cout<<fibo(x)<<endl;
// }