/*
#include<bits/stdc++.h>
using namespace std;
class ovi{
    public:
    int c;
    ovi (int a,int b){
        c=a+b;
        cout<<"Result ="<<c<<endl;

    }
    ovi()
    {
        cout<<"I am default constructor"<<endl;
    }
};
int main(){
    int n1,n2;
    cin>>n1>>n2;
    ovi ob(n1,n2),ob1;
}
*/
#include<bits/stdc++.h>
using namespace std;
class ovi{
    public:
    //float a,b;
    float sum,square,triangle,rectangle;
    ovi (float a,float b){
    
    
        sum=a+b;
        cout<<"Sumation ="<<sum<<endl;

    
    }
    
    ovi(int  a,int b){
        triangle=0.5*a*b;
        cout<<"Area ="<<triangle<<endl;

    }
    ovi(double a){
        square=a*a;
        cout<<"Area2 ="<<square<<endl;

    }
    ovi(float a,int b){
        rectangle=a*b;
        cout<<"Area3 ="<<rectangle<<endl;

    }
};
int main()
{
    float n1,n2;
    cin>>n1>>n2;
    ovi obj(n1,n2), ob(n1,n2),ob1(n1),ob2(n1,n2);

}