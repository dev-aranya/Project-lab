#include<bits/stdc++.h>
using namespace std;
struct bst {
    int data;
}
int main(){
    int t;
    cout<<"Enter the value: "<<endl;
    cin>>t;
    struct 
}