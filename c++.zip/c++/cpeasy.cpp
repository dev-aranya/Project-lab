#include<bits/stdc++.h>.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    int arr[105];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    int easy=1;
    for(int i=0;i<n;i++){
       // cout<<arr[i]<<' ';
       if(arr[i]==1){
        easy=0;
       }
    }
    if(easy==0){
        cout<<"HARD"<<endl;
    }
    else{
        cout<<"EASY"<<endl;
    }
}