x=int(input())
y=int(input())
sum=x+y
if(sum<100):
    print("Small")
else :
    print("Big")        
