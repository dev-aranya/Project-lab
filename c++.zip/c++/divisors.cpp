#include<bits/stdc++.h>
using namespace std;
int main(){
    int a;
    do{
        cout<<endl;
        cin>>a;
        for(int i=1;i<=a;i++)
        {
            if(a%i==0)
            cout<<i<<" ";
        }
    }
    while(a!=-1);
    return 0;
    
}