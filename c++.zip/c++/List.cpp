#include<bits/stdc++.h>
using namespace std;
int main(){
  list<int>li;
  li.push_back(1);
  li.push_back(2);
  li.push_back(3);
  //li.pop_front();
 // li.pop_back();

 // li.push_front(5);
  //li.push_back(6);
/*
  list<int>::iterator it;
  for(it=li.begin();it!=li.end();it++){
    cout<<*it<<" ";
  }
  cout<<endl;
  */
// li.clear();
//li.insert(li.begin(),5);
list<int>::iterator it;
it=li.begin();
advance(it,3);
li.insert(it,6,6);
 for(auto it:li){
    cout<<it<<" ";
 }
 cout<<endl;
 //cout<<li.front()<<endl;
 //cout<<li.back()<<endl;
  //cout<<li.size();
  if(li.empty())cout<<"empty"<<endl;
  else cout<<"Not Empty"<<endl;
}