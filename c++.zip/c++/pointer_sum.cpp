/*
#include<iostream>
using namespace std;
int main()
{
    int a[6]={1,2,4,5,6,8};
    int sum=0,i;
    for(i=0;i<6;i++)
    {
        sum=sum+ *(a+i);
        cout<<*(a+i)<<endl;
    }
    cout<<"Sum ="<<sum<<endl;
    
}

#include<iostream>
using namespace std;
int main()
{
    int b[4]={4,3,6,7};
    int *p=&b[2];
    cout<<*p<<endl;
     cout<<*(p+1)<<endl;
}

#include<iostream>
using namespace std;
void swap(int *n1, int *n2){
    int temp=*n1;
    *n1=*n2;
    *n2=temp;
}
int main()
{
  int num1=6,num2=23;
  cout<<"num1= "<<num1<<endl;
  cout<<"num2= "<<num2<<endl;
  swap(&num1,&num2);
  cout<<"num1= "<<num1<<endl;
  cout<<"num2= "<<num2<<endl;

}
*/
#include<iostream>
using namespace std;
int sum(int *a,int size){
    int i,sum=0;
    for(i=0;i<size;i++){
        sum=sum+ *(a+i);
    }
    return sum;
}
int main(){
    int arr[5]={4,5,6,7,8};
    int result = sum(arr,5);
    cout<<"Sum= "<<result<<endl;

}