#include<bits/stdc++.h>.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    cout<<"Even"<<endl;
    for(int i=0;i<n;i++){
        if(arr[i]%2==0){
            cout<<arr[i]<<' ';
        }
    }
    cout<<endl;
    cout<<"Odd"<<endl;
    for(int i=0;i<n;i++){
        if(arr[i]%2!=0){
            cout<<arr[i]<<' ';
        }
    }
    
}