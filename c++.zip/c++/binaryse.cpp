#include<bits/stdc++.h>
using namespace std;
int main(){
    int arr[5]={2,3,4,5,6};
    cout<<binary_search(arr,arr+5,3)<<"\n";
    cout<<binary_search(arr,arr+5,1)<<"\n";
}