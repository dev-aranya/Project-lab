#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    // for(int i=1;i<=n;i++){
    //     for(int j=1;j<=n;j++){
    //         cout<< j<<" ";
    //     }
    //     cout<<endl;
    // }


    // for(int i=0;i<n;i++){
    //     char ch='A';
    //     for(int j=0;j<n;j++){
    //         cout<< ch<<" ";
    //         ch=ch+1;
    //     }
    //     cout<<endl;
    // }

    //   int num=1;
    // for(int i=0;i<n;i++){
    //     for(int j=0;j<n;j++){
    //         cout<<num<<" ";
    //         num++;
    //     }
    //     cout<<endl;
    // }


    // char ch='A';
    // for(int i=0;i<n;i++){
    //     for(int j=0;j<n;j++){
    //         cout<<ch<<" ";
    //         ch++;
    //     }
    //     cout<<endl;

    // }


    // for(int i=0;i<n;i++){
    //     for(int j=0;j<i+1;j++){
    //         cout<<"*"<<" ";
    //     }
    //     cout<<endl;
    // }

    // for(int i=1;i<=n;i++){
    //     for(int j=1;j<i+1;j++){
    //         cout<<i<<" ";
    //     }
    //     cout<<endl;
    // }

    //  char ch='A';
    // for(int i=1;i<=n;i++){
    //     for(int j=1;j<=i;j++){
    //         cout<<ch<<" ";
    //         //ch++;
    //     }
    //     cout<<endl;
    //     ch++;

    // }


    // for(int i=1;i<=n;i++){
    //     for(int j=1;j<i+1;j++){
    //         cout<<j<<" ";
    //     }
    //     cout<<endl;
    // }


    //  for(int i=1;i<=n;i++){
    //     for(int j=i;j>=1;j--){
    //         cout<<j<<" ";
    //     }
    //     cout<<endl;
    // }


    // for(int i=0;i<n;i++){
    //     for(int j=0;j<i;j++){
    //         cout<<" ";
    //     }
    //     for(int j=0;j<n-i;j++){
    //         cout<<(i+1);
    //     }
    //     cout<<endl;
    // }


    // for(int i=0;i<n;i++){
    //     for(int j=0;j<n-i-1;j++){
    //     cout<<" ";
    // }
    // for(int j=1;j<=i+1;j++){
    //     cout<<j;
    // }
    // for(int j=i;j>0;j--){
    //     cout<<j;
    // }
    // cout<<endl;
    // }


    // hellow Dimond pattren
    // top
    for(int i=0;i<n;i++){
    //   spaces
    for(int j=0;j<n-i-1;j++){
        cout<<" ";
    }
    cout<<"*";
    if(i!=0){
        // spaces
        for(int j=0;j<2*i-1;j++){
            cout<<" ";
        }
        cout<<"*";
    }
    cout<<endl;
    }
    // bottom
    for(int i=0;i<n-1;i++){
        // spaces
        for(int j=0;j<i+1;j++){
            cout<<" ";
        }
        cout<<"*";
        if(i!=n-2){
            // spaces
            for(int j=0;j<2*(n-i)-5;j++){
                cout<<" ";
            }
            cout<<"*";
        }
        cout<<endl;
    }
}