#include<bits/stdc++.h>
using namespace std;
int main(){
    /*
    int a=10;
    int *aptr=&a;

    cout<<*aptr<<endl;
    *aptr=20;
    cout<<a<<endl;
    */
   int arr[]={2,4,56,78,5};
   cout<<*arr<<endl;
   int *ptr=arr;
  // for(int i=0;i<5;i++){
   // cout<<*ptr<<endl;
    //ptr++;
    for(int i=0;i<5;i++){
        cout<<*(arr+i)<<endl;
    }
   }
