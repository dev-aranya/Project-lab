#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t,sum=0;
    cin>>t;
    while(t--){
    
 int n;
 float avg;
    cin>>n;
    int arr[n],sum=0;
    for(int i=1;i<=n;i++)
    {
      cin>>arr[i];
       sum=sum+arr[i];
       
      
    }
    avg=(sum)/n;
    
    //cout<<sum<<endl;
   // cout<<avg;
    int a;
    a=avg*2;
    int i,j;
    for(i=0;i<n-1;i++){
        for(j=i+1;j<n;j++){
            int x=arr[i]+arr[j];
            if(x>a){
            cout<<x;
            }
        }
    }
}
}
    
   
