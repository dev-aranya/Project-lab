#include<bits/stdc++.h>
using namespace std;
int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    long long p,n;
    cin>>p>>n;
    for(int i=1;i<n;i++){
        if(p%2==0) p=p/2;
        else(p=p*3+1);
    }
   cout<<p<<"\n";
   return 0;
}