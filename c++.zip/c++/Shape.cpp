#include<bits/stdc++.h>
using namespace std;
class shape{
    public:
    double width,height;
    
    shape(double a,double b){
        width=a;
        height=b;
        
    }
    double area(){
        return(width*height);
    }
};
int main(){
    shape triangle(65.67,34.45),rectangle(87.76,67.78);
    cout<<"The area of triangle is : "<<0.5*triangle.area()<<endl;
    cout<<"The area of rectangle is : "<<rectangle.area()<<endl;
}