#include<bits/stdc++.h>
using namespace std;
int main(){
 //int a=18,b=9;
 //cout<<min(a,b)<<"\n";

 //cout<<min({3,4,5,6,7,8,1})<<"\n";

 int arr[5]={4,2,6,3,8};
 // cout<<min_element(arr,arr+5) - arr<<"\n";
 //cout<<find(arr,arr+5,7) - arr<<"\n";
 cout<<"before\n";
 for(int i=0;i<5;i++){
    cout<<arr[i]<<" ";
 }
 cout<<"\n";
 sort(arr,arr+5);
 cout<<"after\n";
 for(int i=0;i<5;i++){
    cout<<arr[i]<<" ";
 }
 cout<<"\n";
}