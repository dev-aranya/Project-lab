#include<bits/stdc++.h>
using namespace std;
int main(){
    string s;
    getline(cin,s);
    cout<<s.length()<<endl;
    // s.resize(6);
   // s.resize(30,'*');
   s.at(s.length()-1)='*';
    cout<<s<<endl;

}