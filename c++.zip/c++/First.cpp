#include<iostream>
using namespace std;
int main(){
    cout<<"Amar shoner Bangla ami tumi valobashi";
    cout<<"\nAntu akta asto bokachoda.";
    cout<<"\nAranya devnath ovi";
}