#include<bits/stdc++.h>
using namespace std;
int sum(int a,int b);
int main()
{
    int x,y,res;
    cin>>x>>y;
    res=sum(x,y);
    cout<<"Sumation ="<<res<<endl;
}
int sum(int a,int b){
    int c;
    c=a+b;
    return c;
}