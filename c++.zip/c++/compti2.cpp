// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//     string str,rev;
//     getline(cin,str);
//     for(int i=str.size() - 1;i>=0;i--){
//        // rev=rev+str[i];
//        rev.push_back(str[i]);
//     }
//     cout<<rev<<endl;
//     if(str==rev){
//         cout<<"Yes";
//     }else{
//         cout<<"No";
//     }
// }



// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//     int n,m;
//     cin>>n>>m;
//     int a[n][m];
//     for(int i=0;i<n;i++){
//         for(int j=0;j<m;j++){
//             cin>>a[i][j];
//         }
//     }
//     for(int i=0;i<n;i++){
//         for(int j=0;j<m;j++){
//             cout<<a[i][j]<<" ";
//         }
//         cout<<endl;
//     }
// }


#include<bits/stdc++.h>
using namespace std;
int digit_sum(int n){
    int sum=0;
    while(n){
        sum=sum+n%10;
        n=n/10;
    }
    return sum;
}
int main(){
    int a,b;
    cin>>a>>b;
    cout<<digit_sum(a) + digit_sum(b);
}