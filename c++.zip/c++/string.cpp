#include<bits/stdc++.h>
using namespace std;
int main(){
    string name;
    cin>>name;
    cout<<"Hello,"<<name<<endl;
    
}