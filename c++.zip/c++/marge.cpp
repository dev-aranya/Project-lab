// #include<bits/stdc++.h>
// using namespace std;

// const int mx = 2e5+123;

// int ar[mx];

// void Merge(int l,int mid,int r)
// {
//     int p = l;
//     int q = mid+1;
//     int len = r-l+1 ;
//     vector<int>v(len);
//     int k=0;
//     for(int i=l;i<=r;i++)
//     {
//         if(p > mid)
//         {
//             v[k] = ar[q];
//             k++,q++;
//         }
//         else if(q>r)
//         {
//             v[k] = ar[p];
//             k++,p++;
//         }
//         else if(ar[p] <= ar[q])
//         {
//             v[k] =ar[p];
//             k++,p++;
//         }
//         else
//         {
//             v[k] = ar[q];
//             k++,q++;
//         }
//     }
//     k=0;
//     for(int i=l;i<=r;i++)
//     {
//         ar[i] = v[k];
//         k++;
//     }
// }
// void merge_sort(int l,int r)
// {
//     if(l==r) return;
//     int mid = (l+r)/2;
//     merge_sort(l,mid);
//     merge_sort(mid+1,r);
//     Merge(l,mid,r);
// }
// int main()
// {
//     int n;
//     cin>>n;
//     for(int i=1;i<=n;i++)
//     {
//         cin>>ar[i];
//     }
//     merge_sort(1,n);
//     for(int i=1;i<=n;i++)
//     {
//         cout<<ar[i]<< " ";
//     }
// }



#include<bits/stdc++.h>
using namespace std;
void merge ( int *arr,int s,int e){
    int mid =(s+e)/2;

    int len1=mid-s+1;
    int len2=e-mid;

    int *first=new int[len1];
    int *second=new int[len2];
    //copy values
    int mainarrayindx=s;
    for(int i=0;i<len1;i++){
        first[i]=arr[mainarrayindx++];
    }
    int k=mid+1;
    for(int i=0;i<len2;i++){
        second[i]=arr[mainarrayindx++];
    }

    //merge 2 sort array
    int index1=0;
    int index2=0;
    mainarrayindx=s;

    while(index1<len1 && index2<len2){
        if(first[index1]<second[index2]){
            arr[mainarrayindx++]=first[index1++];
        }
        else{
            arr[mainarrayindx++]=second[index2++];
        }
    }
    while (index1<len1){
         arr[mainarrayindx++]=first[index1++];
    }
    while(index2<len2){
         arr[mainarrayindx++]=second[index2++];
    }
}

void mergesort( int *arr,int s,int e){
    //base case 
    if(s>=e){
        return;
    }
    int mid =(s+e)/2;
    //left part sort
    mergesort(arr,s,mid);
    //right part sort
    mergesort(arr,mid+1,e);
    //merge
    merge(arr,s,e);
}


int main(){
      
    int n=5;
    int arr[5]={2,3,1,7,2};
    mergesort(arr,0,n-1);
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";

    }
    cout<<endl;
    return 0;
    
}