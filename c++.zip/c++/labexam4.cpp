#include <iostream>
using namespace std;

class Shape
{
public:
  virtual double area() = 0;
};

class Circle : public Shape
{
private:
  int radius;

public:
  Circle(int a)
  {
    radius = a;
  }

  double area() override
  {
    return 3.14159 * radius * radius;
  }
};

class Square : public Shape
{
private:
  int side;

public:
 Square(int x)
  {
    side = x;
  }

  double area() override
  {
    return side * side;
  }
};

int main()
{
  Circle y(7);
  Square x(10);

  Shape &shape1 = y;
  Shape &shape2 = x;

  cout << "Area of Circle: " << shape1.area() << endl;
  cout << "Area of Square: " << shape2.area() << endl;

}