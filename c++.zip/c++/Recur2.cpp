// #include<bits/stdc++.h>
// using namespace std;

// string removedup(string s){
//     if(s.length()==0){
//        return "";
//     }
//     char ch = s[0];
// string ans = removedup(s.substr(1));

//  if (ch==ans[0]){
//     return ans;
// }
//  return (ch+ans);
// }

// int main(){
//     cout<<removedup("aaapnajskjkkkkiiio");
//     return 0;
// }



// #include<bits/stdc++.h>
// using namespace std;

// string move_all_x(string s){
//     if(s.length()==0){
//         return "";
//     }
//     char ch=s[0];
//     string ans=move_all_x(s.substr(1));

//     if(ch=='x'){
//         return ans+ch;
//     }
//     return ch+ans;
// }

// int main(){
//     cout<<move_all_x("axxbdefxxhix");
//     return 0;
// }




#include<bits/stdc++.h>
using namespace std;
void sub_seq(string s,string ans){
    if(s.length()==0){
        cout<<ans<<endl;
        return;
    }
    char ch=s[0];
    string ros=s.substr(1);

    sub_seq(ros,ans);
    sub_seq(ros,ans+ch);
}

int main(){
    sub_seq("ABC","");
    return 0;
}
