#include<bits/stdc++.h>
using namespace std;
int main(){
    /*
    vector<int >v;
    v.push_back(5);
    v.push_back(6);
    v.push_back(7);
    v.push_back(8);
    v.push_back(9);
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
   // v.insert(v.begin()+2,2);
   v.insert(v.begin()+2,3,2);
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
    
   vector<int >v1;
    v1.push_back(5);
    v1.push_back(6);
    v1.push_back(7);
    v1.push_back(8);
    v1.push_back(9);

    vector<int >v2;
    v2.push_back(1);
    v2.push_back(2);
    v2.push_back(3);
    v2.push_back(4);
    v2.push_back(5);
    cout<<"Before swaping"<<endl;
    for(int i=0;i<v1.size();i++){
        cout<<v1[i]<<" ";
    }
    cout<<endl;
    for(int i=0;i<v2.size();i++){
        cout<<v2[i]<<" ";
    }
    cout<<endl;
    swap(v1,v2);
    cout<<" After swaping"<<endl;
    for(int i=0;i<v1.size();i++){
        cout<<v1[i]<<" ";
    }
    cout<<endl;
    for(int i=0;i<v2.size();i++){
        cout<<v2[i]<<" ";
    }
    cout<<endl;

  
  vector<int>v;
  v.push_back(1);
  v.push_back(6);
  v.push_back(9);
  v.push_back(4);

  for(int i=0;i<v.size();i++){
    cout<<v[i]<<" ";
  }
  cout<<endl;
  sort(v.begin(),v.end());

   for(int i=0;i<v.size();i++){
    cout<<v[i]<<" ";
  }
   

  vector<int>v;
  v.push_back(1);
  v.push_back(6);
  v.push_back(9);
  v.push_back(4);

  for(int i=0;i<v.size();i++){
    cout<<v[i]<<" ";
  }
  cout<<endl;
  reverse(v.begin(),v.end());
  
   for(int i=0;i<v.size();i++){
    cout<<v[i]<<" ";
  }
*/
   vector<int>v1;
  v1.push_back(1);
  v1.push_back(6);
  v1.push_back(9);
  v1.push_back(4);

  vector<int>::iterator it;
  //it=v1.begin()+3;
  //cout<<*it<<endl;
  for(it=v1.begin();it!=v1.end();it++){
    cout<<*it<<endl;
  }

}
