/*
#include<iostream>
using namespace std;
int main(){
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
}

#include<iostream>
using namespace std;
int main(){
    int n;
    cin>>n;
    int arr[n],sum=0;
    for(int i=0;i<n;i++)
    {
      cin>>arr[i];
       sum=sum+arr[i];
      
    }
    
    for(int i=0;i<n;i++){
       
        cout<<arr[i]<<" "<<endl;
        
    }
    cout<<"sum"<<sum;
}
*/

#include<iostream>
using namespace std;
int main(){
    int n;
    cin>>n;
    int arr[n],sum=0;
     for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    for(int i=0;i<n;i++){
       // cin>>arr[n];
        sum=sum+ arr[i];
        cout<<arr[i]<<" ";
    }
   
    cout<<" sum ="<<sum<<endl;
}

/*
#include<iostream>
using namespace std;
int main(){
    int arr[5]={2,3,5,7,8};
    int *p=&arr[2];
    cout<<*p<<endl;
    cout<<*(p+1)<<endl;
    cout<<*(p+2)<<endl;
    cout<<*(p-1)<<endl;
}

#include<iostream>
using namespace std;
void swap(int *n1,int *n2){
    int temp=*n1;
    *n1=*n2;
    *n2=temp;
}
int main(){
int num1=5,num2=9;
cout<<"num1 ="<<num1<<endl;
cout<<"num2 ="<<num2<<endl;
swap(num1,num2);
cout<<"num1 ="<<num1<<endl;
cout<<"num2 ="<<num2<<endl;
}

#include<iostream>
using namespace std;
int sum(int *a, int size){
    int i,sum=0;
    for(i=0;i<size;i++){
        sum=sum+*(a+i);
    }
    return sum;
}
int main(){
    int arr[5]={3,4,5,6,7};
    int arr1[5]={3,4,5,61,7};
    int result=sum(arr,5);
    int result1=sum(arr1,5);
    cout<<"Sum ="<<result<<endl;
    cout<<"Sum ="<<result1<<endl;
}

#include<iostream>
//#include<climits>
using namespace std;
int main(){
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    int max=arr[0];
    int min=arr[0];
    for(int i=0;i<n;i++){
        if(max<arr[i]){
            max=arr[i];
        }
        if(min>arr[i]){
            min=arr[i];
        }
       // max=max(max,arr[i]);
       // min=min(min,arr[i]);
    }
    cout<<max<<" "<<min<<endl;
}
*/
