#include<bits/stdc++.h>
using namespace std;
int main(){
    int i,j,n,count=0;
    cin>>n;
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            count=count+1;
        }
    }
    for(i=0;i<n;i++){
        count=count+1;
    }
    cout<<n<<" "<<count;
}