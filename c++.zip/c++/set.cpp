#include<bits/stdc++.h>
using namespace std;
int main(){
    //set<int>s;
    set<int,greater<int> >s;
    s.insert(1);
    s.insert(2);
    s.insert(3);
    s.insert(4);
    // cout<<s.size()<<endl;
    // cout<<s.max_size()<<endl;

    // set<int>::iterator it;
    // for(it=s.begin();it!=s.end();it++){
    //     cout<<*it<<" ";
    // }

    // for(auto it:s)cout<<it<<" ";
    // cout<<endl;

    // s.clear();

    // if(s.empty()) cout<<"Empty"<<endl;
    // else cout<<"Not Empty"<<endl;
     
     //s.erase(3);
    //  set<int>::iterator it;
    //  it=s.begin();
    //  advance(it,2);
    //  s.erase(it);

    // for(auto it:s) cout<<it<<" ";
    // cout<<endl;

    
}