#include<iostream>
using namespace std;
int main()
{
    int a,b;
    
    cin>>a>>b;
   // int c=a+b;
   // return c;
    
    cout<<"sum ="<<a+b<<endl;
    cout<<"Hello Bangladesh"<<endl;
    return 0;
}