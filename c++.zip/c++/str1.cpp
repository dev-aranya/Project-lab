#include<bits/stdc++.h>
using namespace std;
int main(){
    // string s="Hello";
    // s[3]='a';
   // string s="We are so called \"vikings\" from the north.";
     string s;
     cout<<"Enter full name=";
     getline(cin,s);
    cout<<s<<endl;
}