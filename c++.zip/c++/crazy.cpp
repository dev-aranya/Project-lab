#include<bits/stdc++.h>
using namespace std;
int main(){
    int a,b,rev=0,tem;
    cin>>a>>b;
    while(b!=0)
    {
       tem=b%10;
       rev=rev*10+tem;
       b=b/10;
    }
    cout<<a+rev<<endl;
}