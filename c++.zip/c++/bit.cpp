#include<bits/stdc++.h>
using namespace std;

int getbit(int n,int pos){
    return ((n&(1<<pos))!=0);

}
int setbit(int n,int pos){
    return(n | (1<<pos));
}
int main()
{
    //cout<<getbit(5,2)<<endl;
     cout<<setbit(5,1)<<endl;

}