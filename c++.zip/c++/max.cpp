#include<bits/stdc++.h>
using namespace std;
int main(){
    long long n;
    
    cin >> n;

    // ovi
    int max_sum = INT_MIN;
    int best_x = 2;

    // Loop 
    for (int x = 2; x <= n; ++x) {
        
        int sum = 0;
        for (int k = 1; k * x <= n; ++k) {
            sum += k * x;
        }

        
        if (sum > max_sum) {
            max_sum = sum;
            best_x = x;
        }
    }

    // Output the result
    cout << best_x <<endl;

    return 0;
}
