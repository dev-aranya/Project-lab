#include<bits/stdc++.h>
using namespace std;
int main(){
    /*
    long long a;
    int flag=0;
    while(cin>>a){
        if(a==0)break;
        else if(a<0){
            flag=1;
        }
    }
    if(flag==0){
        cout<<" NO";
    }
    else {
        cout<<" YES";
    }
    */
   long long a;
   int count=0;
   while(cin>>a){
    if(a==0)break;
    if (a<0){
        count++;
    }
   }
   cout<<count<<endl;
}