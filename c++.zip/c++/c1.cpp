#include<bits/stdc++.h>
using namespace std;
int main()
{
    int  a;
    cin>>a;
    for(int i=1;i<=a;i++)
    {
        if(i==10)
        {
            //continue;
            break;
        }
        cout<<i<<endl;
    }
    
}