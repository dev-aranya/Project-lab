#include<bits/stdc++.h>
using namespace std;
int main(){
    int amount,balance;
    cin>>amount>>balance;
    double remain_bal;
    if(amount%5==0){
       if((amount + 0.5)<=balance ){
        remain_bal=balance-amount-(0.5);
        cout<<remain_bal<<endl;
       }
       else
        cout<<balance<<endl;
    }
    else{
        cout<<balance<<endl;
    }
}