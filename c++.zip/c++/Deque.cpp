#include<bits/stdc++.h>
using namespace std;
int main(){
    deque<int>dq;
    dq.push_back(1);
    dq.push_back(2);
    dq.push_back(3);
    dq.push_back(4);
    //dq.push_front(5);
    //dq.pop_front();
    //dq.pop_back();
     //dq.clear();
    //cout<<dq.size();
    deque<int>::iterator it;
    it=dq.begin()+3; 
    dq.erase(it);
    for(int i=0;i<dq.size();i++){
        //cout<<dq[i]<<" ";
        cout<<dq.at(i)<<" ";
    }
    cout<<endl;
   //cout<<dq.front()<<endl;
   //cout<<dq.back()<<endl;
   //if(dq.empty())cout<<"Empty"<<endl;
   //else cout<<"Not empty"<<endl;
}