/*
#include<iostream>
using namespace std;
int sum(int a,int b);
int main()
{
    int x,y,result;
    cin>>x>>y;
    result = sum(x,y);
    cout<<"The Result is ="<<result<<endl;
}
int sum(int n1,int n2)
{
    int n3;
    n3=n1+n2;
    return n3;
}
*/


#include<iostream>
using namespace std;
int sum(int a,int b);

int main()
{
    int x,y,result;
    cin>>x>>y;
     result=sum(x,y);
    cout<<"The Result="<<result<<endl;
}
int sum(int n1,int n2)
{
    int n3;
    n3=n1+n2;
    return n3;
}
