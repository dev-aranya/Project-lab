#include<iostream>
using namespace std;

class dad{
 public :
 int moneyfromdad;
 void getmoneyfromdad()
 {
    cin>>moneyfromdad;
 }
};

class mom{
   public:
 int money1;
 void getmoneyfrommom()
 {
    cin>>money1;
 }
};

class sister{
   public:
 int money2;
 void getmoneyfromsister()
 {
    cin>>money2;
 }
};

class ovi : public dad, public mom, public sister{
 //private :
 
 public :
 int totalmoney;
  void gettotalmoney()
  {
    totalmoney=moneyfromdad+money1 +money2;
    cout<<"Total amount"<<totalmoney<<endl;
  }

};

int main()
{
    ovi s1;
    s1.getmoneyfromdad();
    s1.getmoneyfrommom();
    s1.getmoneyfromsister();
    s1.gettotalmoney();
}
