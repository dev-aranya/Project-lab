#include<bits/stdc++.h>
using namespace std;
int main(){
    vector<int> v;
    v.push_back(10);
    v.push_back(23);
    v.push_back(24);
    v.push_back(2);

    sort(v.begin(),v.end());
    v.pop_back();
    int k=(int)v.size();
    for(int i=0;i<k;i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
}