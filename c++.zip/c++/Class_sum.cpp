/*
#include<bits/stdc++.h>
using namespace std;
class ovi{
    public:
    int a,b,c;
    void display()
    {
        cin>>a>>b;
        c=a+b;
        cout<<"Sumation ="<<c<<endl;
    }
};
int main()
{
    ovi ob;
    ob.display();
}
*/
#include<bits/stdc++.h>
using namespace std;
class ovi{
    public:
    int c;
    void display(int a,int b)
    {
        
        c=a+b;
        cout<<"Sumation ="<<c<<endl;
    }
};
int main()
{
    int a,b;
    cin>>a>>b;
    ovi ob;
    ob.display(a,b);
}
