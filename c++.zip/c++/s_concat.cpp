#include<bits/stdc++.h>
using namespace std;
int main(){
    // string a="Ovi ";
    // string b="Deb nath";
    //string c=a +" "+b;
    // string c=a.append(b);
    // cout<<b.length()<<endl;
    // cout<<b.size()<<endl;
    // cout<<c<<endl;
    // cout<<b[2]<<endl;
    // cout<<a[1]<<endl;
    // cout<<b[b.length() -1];
    // a[0]='A';
    // cout<<a<<endl;
    //string name;
    //cin>>name;
    // getline(cin,name);
    // cout<<name<<endl;
    cout<<min(4,6)<<endl;
    cout<<sqrt(64)<<endl;
    cout<<round(3.4)<<endl;
    cout<<log(3)<<endl;

}