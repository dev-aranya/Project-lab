#include<bits/stdc++.h>
using namespace std;
int main(){
    int arr[7]={3,-4,-5,-6,8,9,0};

   //for(int i=7-1;i>=0;i--){
  // cout<<arr[i]<<" ";
  // }
  /*
  for(int i=0;i<7;i++){

    if(arr[i]<0){
         arr[i]=arr[i]*-1;
       
    }
     cout<<arr[i]<<" ";
    
  }
  */
  for(int i=0;i<7;i++){
    if(arr[i]%2==0)
    cout<<arr[i]<<" ";
  }
}