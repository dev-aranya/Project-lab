#include<bits/stdc++.h>
using namespace std;
int linear_search(int arr[],int size,int key)
    {
        int i;
        for(i=0;i<size;i++){
            if(arr[i]==key){
                return i;
            }
        }
        return -1;
    }
int main(){
    int n;
    cin>>n;
    int ar[n];
    for(int i=0;i<n;i++){
        cin>>ar[i];
    }
    int key;
    cin>>key;
    cout<<linear_search(ar,n,key)<<endl;
    
}