#include<bits/stdc++.h>
using namespace std;
int main()
{
    /*
    long long a,b;
    int t;
    cin>>t;
   
    for(int i=0;i<t;i++){
       cin>>a>>b;
        cout<<a+b<<endl;
    }

  
   long long a,b;
   while(1){
    cin>>a>>b;
    if(a==0 && b==0){
        break;
    }
    cout<<a+b<<endl;
   }
    


    string line;
    while(getline(cin,line)){
        cout<<line <<endl;
    }
     */

    long long a,b;
    int t;
    cin>>t;
   
   while(t--){
       cin>>a>>b;
        cout<<a+b<<endl;
    }
   return 0;
}