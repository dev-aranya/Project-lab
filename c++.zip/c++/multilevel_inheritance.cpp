#include<iostream>
using namespace std;

class student{
 private :
 int roll;
 public :
 void setroll(int a){
    roll=a;
 }
 void getroll(){
    cout<<"The roll is "<<roll<<endl;
 }
};

class exam : public student {
  protected :
  double bangla;
  double english;
  double math;
  public :
    void setmark(double b,double e,double m){
     bangla=b;
     english=e;
     math=m;   
    }
    void getmark(){
        cout<<"Marks in Bangla is ="<<bangla<<endl;
        cout<<"Marks in English is="<<english<<endl;
        cout<<"Marks in math is="<<math<<endl;
    }
};

class result: public exam{
 public :
 void display(){
    getroll();
    getmark();
    cout<<"The result is ="<<(bangla+english+math)/3<<endl;
 }
};

int main()
{
    result ob;
    ob.setroll(32);
    ob.setmark(87.67,89.00,90.66);
    ob.display();
}
