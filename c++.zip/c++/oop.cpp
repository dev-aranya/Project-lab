#include<bits/stdc++.h>
using namespace std;

class student{
    public:
    string name;
    int age;
    bool gender;

    void printinfo(){
        cout<<"name=";
        cout<<name<<endl;
        cout<<"Age=";
        cout<<age<<endl;
        cout<<"Gender=";
        cout
    }
}