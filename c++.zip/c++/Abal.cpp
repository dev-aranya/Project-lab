#include<iostream>
using namespace std;
int main(){
    while(1){
        int a;
    cout<<"Input an integer: ";
    cin>>a;
    if(a>=1){
        cout<<"Antu is a bokachode."<<endl;
    }
    else if(a<0){
        cout<<"Antu is a matari."<<endl;
    }
    else{
        cout<<"Antu is a chudani."<<endl;
    }
    }
}