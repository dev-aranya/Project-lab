// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//     int t;
//     cin>>t;
//     while(t--){
//     int n;
//     cin>>n;
//     int M=47;
//     long long fact=1;
//     for(int i=2;i<=n;i++){
//         fact=(fact*i)%M;
//     }
//     cout<<fact<<endl;
// }
// }


// #include<bits/stdc++.h>
// using namespace std;
// const int M=1e9+7;
// const int N=1e5+10;
// long long fact[N];

// int main(){
//     fact[0]=fact[1]=1;
//     for(int i=2;i<N;i++){
//         fact[i]=fact[i-1]*i;
//     }
//     int t;
//     cin>>t;
//     while(t--){
//         int n;
//         cin>>n;
//         cout<<fact[n]<<endl;
//     }
// }


// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//     int n;
//     cin>>n;
//     int a[n];
//     for(int i=0;i<n;i++){

//         cin>>a[i];
//     }
//     int q;
//     cin>>q;
//     while(q--){
//         int x;
//         cin>>x;
//         int ct=0;
//         for(int i=0;i<n;i++){
//             if(a[i]==x){
//                 ct++;

//             }
//             cout<<ct<<endl;
//         }
//     }
// }


#include<bits/stdc++.h>
using namespace std;
const int N=1e7+10;
int hsh[N];
int main(){
    int n;
    cin>>n;
    int a[n];
    for(int i=0;i<n;i++){
        cin>>a[i];
        hsh[a[i]++];
    }
    int q;
    cin>>q;
    while(q--){
        int x;
        cin>>x;
        
            cout<<hsh[x]<<endl;
        }
    }
