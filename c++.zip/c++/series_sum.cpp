#include<bits/stdc++.h>
using namespace std;

int sum(int n){
    int sum=0;
    for(int i=1;i<=n;i++){
        sum=sum+i;
    }
    return sum;
}

int main(){
    int n;
    cin>>n;
    int add=sum(n);
    cout<<"sumation ="<<add<<endl;
}