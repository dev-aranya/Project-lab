#include<bits/stdc++.h>
using namespace std;
int main()
{
    string a, b;
    
    // ovi
    
    cin >> a>>b;
    // Ensure 
    if (a.length() != 3 || b.length() != 3) {
        // std::cerr << "Both strings must be of length 3." << std::endl;
        return 1;
    }
    
    char temp = a[0];
    a[0] = b[0];
    b[0] = temp;
    
    // Output the new strings
    // cout << "After swapping the first characters:" << endl;
    cout << a <<" "<<b ;
    
    
    return 0;
}