#include<bits/stdc++.h>
using namespace std;

// Function to find LCS length and also print the LCS
void LCS(string X, string Y) {
    int m = X.length();
    int n = Y.length();

    // Create a DP table
    vector<vector<int>> dp(m + 1, vector<int>(n + 1, 0));

    // Build the table in bottom-up manner
    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++) {
            if (X[i - 1] == Y[j - 1])  // if characters match
                dp[i][j] = dp[i - 1][j - 1] + 1;
            else  // if not match, take max of top or left
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
        }
    }

    // LCS length
    cout << "Length of LCS: " << dp[m][n] << endl;

    // Now, reconstruct the LCS string
    string lcs = "";
    int i = m, j = n;

    while (i > 0 && j > 0) {
        if (X[i - 1] == Y[j - 1]) {
            lcs = X[i - 1] + lcs;
            i--; j--;
        }
        else if (dp[i - 1][j] > dp[i][j - 1])
            i--;
        else
            j--;
    }

    cout << "LCS string: " << lcs << endl;
}

// Main function
int main() {
    string str1, str2;

    cout << "Enter first string: ";
    cin >> str1;

    cout << "Enter second string: ";
    cin >> str2;

    LCS(str1, str2);

    return 0;
}
