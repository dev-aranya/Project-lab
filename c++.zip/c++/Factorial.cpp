#include<bits/stdc++.h>
using namespace std;

int fact(int n){
    int fact=1;
    for(int i=2;i<=n;i++){
       // cout<<"Factorial ="<<fact<<endl;
        fact=fact*i;
    
    }
    return fact;
   //cout<<"Factorial ="<<fact<<endl;
}

int main(){
    int a;cin>>a;
    int ans= fact(a);
    cout<<"Factorial ="<<ans<<endl;
}