#include<bits/stdc++.h>
using namespace std;

int fact(int a){
    int fact=1;
    for(int i=2;i<=a;i++){
        fact=fact*i;
    }
    return fact;
}

int main(){
    int n,r;
    cin>>n>>r;
    int ans=fact(n)/(fact(r)*fact(n-r));
    cout<<"NCR ="<<ans<<endl;
}