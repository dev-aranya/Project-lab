/*
#include<iostream>
using namespace std;

class Addition
{
 public :
 int a,b,c;

 void result()
 {
    cin>>a>>b;
    c=a+b;
    cout<<"The result is "<<c<<endl;
 }
};

int main()
{
    Addition ob;
    ob.result();

}
*/
/*
#include<iostream>
using namespace std;

class Addition
{
 public :
 int a,b,c;
 void display()
 {
    cin>>a>>b;
    c=a+b;
    cout<<"The Result = "<<c<<endl;
 }
};

int main()
{
    Addition s1;
    s1.display();
}
*/
/*
#include<iostream>
using namespace std;
class Multiplication
{
 public:
 int c;
 Multiplication (int a, int b)
 {
   // cin>>a>>b;
    c=a*b;
    cout<<"The Result is = "<<c<<endl;
 }
};

int main()
{
    int a,b;
    cin>>a>>b;
    Multiplication s1(a,b);
    //s1.display();

}
*/
#include<iostream>
using namespace std;
class avg
{
 public :
 float x,y;
 avg (int a,int b,int c,int d)
 {
    x=a+b+c+d;
    y=x/4.0;
    cout<<"Avg ="<<y<<endl;
 }
};

int main()
{
    int p,q,r,s;
    cin>>p>>q>>r>>s;
    avg s1(p,q,r,s);
}