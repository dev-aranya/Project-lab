#include<iostream>
using namespace std;
int main(){
    int a,b;
    cout<<"Input two integer: ";
    cin>>a>>b;
    int sum=a+b;
    cout<<"The summation is: "<<sum<<endl;
}