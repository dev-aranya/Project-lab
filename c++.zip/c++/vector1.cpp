#include<bits/stdc++.h>
using namespace std;
int main(){
    vector<int>v;
       v.push_back(6);
       v.push_back(2);
       v.push_back(9);
       v.push_back(4);

    // cout<<v[0]<<" ";
    // cout<<v[1]<<endl;

    // cout<<v.at(0)<<" ";
    // cout<<v.at(1)<<endl;

   //cout<< v.size()<<endl;
   for(int i=0;i<v.size();i++){
    cout<<v[i]<<" ";
   }
   cout<<endl;
//    cout<<v.front()<<endl;
//    cout<<v.back()<<endl;
// cout<<v.size()<<endl;
// //v.clear();
// cout<<v.size()<<endl;
// if(v.empty())
// cout<<"Empty"<<endl;
// else
// cout<<"Not Empty"<<endl;
// v.pop_back();
// for(int i=0;i<v.size();i++)
// {
//    cout<<v[i]<<" ";
// }

//v.erase(v.begin()+0);
// v.erase(v.begin()+0,v.begin()+2);
// for(int i=0;i<v.size();i++){
//    cout<<v[i]<<" ";
// }

//v.insert(v.begin()+1,34);
// v.insert(v.begin(),3,5);
// for(int i=0;i<v.size();i++){
//    cout<<v[i]<<" ";
// }

// vector<int>v1;
// v1.push_back(8);
// v1.push_back(7);
// v1.push_back(6);

// cout<<"Before swaping"<<endl;
// for(int i=0;i<v.size();i++){
//    cout<<v[i]<<" ";
// }
// cout<<endl;
// for(int i=0;i<v1.size();i++){
//    cout<<v1[i]<<" ";
// }
// cout<<endl;
// swap(v,v1);
// cout<<" After swaping "<<endl;
// for(int i=0;i<v.size();i++){
//    cout<<v[i]<<" ";
// }
// cout<<endl;
// for(int i=0;i<v1.size();i++){
//    cout<<v1[i]<<" ";
// }

// cout<<"Before sorting "<<endl;
// for(int i=0;i<v.size();i++){
//    cout<<v[i]<<" ";
// }
// cout<<endl;
// sort(v.begin(),v.end());
// cout<<"after sorting"<<endl;
// for(int i=0;i<v.size();i++){
//    cout<<v[i]<<" ";
// } 
// cout<<"Before reverse "<<endl;
// for(int i=0;i<v.size();i++){
//    cout<<v[i]<<" ";
// }
// cout<<endl;
// reverse(v.begin(),v.end());
// cout<<"after reverse"<<endl;
// for(int i=0;i<v.size();i++){
//    cout<<v[i]<<" ";
// } 
vector<int>::iterator it;
// it=v.begin()+2;
// cout<<*it<<endl;
for(it=v.begin();it!=v.end();it++){
   cout<<*it<<" ";
}

}
      