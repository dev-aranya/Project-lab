#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long n;
    cin>>n;
    int c=0;
    for(int i=0;i<n;i++){
        int x,y,z;
        cin>>x>>y>>z;
        if((x+y+z)>=2){
            c++;
        }
    }
    cout<<c<<endl;
    return 0;
}