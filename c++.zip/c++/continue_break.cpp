#include<bits/stdc++.h>
using namespace std;
int main(){
   // int n;
    //cin>>n;
    for(int i=0;i<23;i++){
        if(i%3==0){
            continue;
        }
        if(i==34){
            break;
        }
        cout<<i<<endl;
    }
}