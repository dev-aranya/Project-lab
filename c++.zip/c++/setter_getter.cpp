/*
#include<iostream>
using namespace std;

class student
{
 public:
 double gpa;
 void display()
 {
    cout<<gpa;
 }
};

int main()
{
    student ob;
    ob.gpa=3.88;
    ob.display();
}

#include<iostream>
using namespace std;

class ovi
{
  public:
  double gpa;
  void out()
  {
    cout<<gpa;
  }
};

int main()
{
    ovi s1;
    s1.gpa=4.00;
    s1.out();
}

#include<iostream>
using namespace std;

class ovi
{
 private :
  double gpa;
  public :
  void setgpa(double a)
  {
    gpa=a;
  }
  double getgpa()
  {
    return gpa;
  }
};
int main()
{
    ovi ob;
    ob.setgpa(3.89);
    cout<< ob.getgpa()<<endl;
}

#include<iostream>
using namespace std;
class ovi
{
 private :
 double a,b,c,d;
 public :
 float y,x;
 void setvalue(double n1,double n2,double n3)
 {
    a=n1;
    b=n2;
    c=n3;
 }
 double getvalue()
 {
    x=a+b+c;
    y=x/3.0;
    cout<<"Avg ="<<y<<endl;
 }
};
int main()
{
    ovi s1;
    s1.setvalue(3.24,4.5,44);
    s1.getvalue();
}
*/
#include<iostream>
using namespace std;

class ovi
{
 private :
 float a,b,c,d;
 public :
 float x,y;
 void setvalue(int n1,int n2,int n3)
 {
    a=n1;
    b=n2;
    c=n3;
 }

void getvalue()
{
  x=a+b+c;
  y=a*b*c;
  cout<<"The Multiplication = "<< y<<endl;
  cout<<"The sumation ="<<x<<endl;    

}
};
int main()
{
    ovi ob;
    ob.setvalue(34,556,7);
    ob.getvalue();
}