#include<iostream>
using namespace std;

class Addition{
 public :

 void learn()
 {
    cout<<"Selection Operator"<<endl;
 }
};

int main()
{
    Addition ob;
    Addition *p;
    p->learn();
}
