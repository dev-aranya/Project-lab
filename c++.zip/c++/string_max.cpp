#include<bits/stdc++.h>
using namespace std;
int main(){
    /*
    string s="3467657987";
    sort (s.begin(),s.end(),greater<int>());
    cout<<s<<endl;
    */
   string s="hdfghhdjhgjdhkjjkgfh";
   int freq[26];
   for(int i=0;i<26;i++)
   freq[i]=0;
   for(int i=0;i<s.size();i++){
    freq[s[i]-'a']++;
   }
   char ans='a';
   int maxf=0;
   for(int i=0;i<26;i++){
    if(freq[i]>maxf)
    {
        maxf=freq[i];
        ans=i+'a';
    }
   }
   cout<<maxf<<" "<<ans<<endl;
}