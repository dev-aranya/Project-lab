#include<bits/stdc++.h>
using namespace std;
int main(){
    int a,n=0;
    cin>>a;
    string s;
    while(a--){
        cin>>s;
        if(s=="++X"|| s=="X++"){
            n++;
        }
        if(s=="--X"|| s=="X--"){
            n--;
        }
    }
    cout<<n<<endl;
    return 0;
}