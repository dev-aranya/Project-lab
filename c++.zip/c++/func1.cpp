#include<bits/stdc++.h>
using namespace std;
// sum of 2 num
double sum(double a,double b){
    int s=a+b;
    return s;
}
// min of 2 nums
int minoftwo(int a,int b){
    if(a<b){
        return a;
    }else{
        return b;
    }
}
// 1 to n sum
int sumN(int n){
   int sum=0;
   for(int i=1;i<=n;i++){
    sum+=i;
   }
   return sum;
}
// factorial
int factorial(int n){
    int fact=1;
    for(int i=1;i<=n;i++){
        fact*=i;
    }
    return fact;
}


int main(){
    cout<<sum(10.99,5.87)<<endl;
    cout<<"min="<<minoftwo(6,7)<<endl;
    cout<<" N sum= "<<sumN(19)<<endl;
    cout<<"Factorial="<<factorial(5)<<endl;
    }