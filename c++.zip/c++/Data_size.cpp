#include<bits/stdc++.h>
using namespace std;
int main(){
    int a;
    cout<<"Size ="<<sizeof(a)<<endl;
    float b;
     cout<<"Size ="<<sizeof(b)<<endl;
     double d;
     cout<<"Size ="<<sizeof(d)<<endl;
     bool c;
     cout<<"Size ="<<sizeof(c)<<endl;
     char e;
      cout<<"Size ="<<sizeof(e)<<endl;
      short int si;
      cout<<"Size ="<<sizeof(si)<<endl;
      long int li;
      cout<<"Size ="<<sizeof(li)<<endl;
    
}