#include<bits/stdc++.h>
using namespace std;
int main(){
    stack<int>st;
    st.push(1);
    st.push(2);
    st.push(3);
    st.push(5);
     
    // st.pop();
    // if(st.empty())cout<<"Empty"<<endl;
    // else cout<<"Not empty"<<endl;
    // cout<<st.size()<<endl;
    // cout<<st.top()<<endl;
    //while(!st.empty())
    while(st.size()>0){
        cout<<st.top()<<" ";
        st.pop();
    }
}