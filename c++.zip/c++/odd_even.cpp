#include<bits/stdc++.h>
using namespace std;
int main(){
    int a;
    cin>>a;
    if(a%2==0)
    cout<<"Even"<<endl;
    else 
    cout<<"Odd"<<endl;
}