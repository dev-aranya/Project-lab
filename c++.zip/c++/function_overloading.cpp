/*
#include<iostream>
using namespace std;

class ovi
{
   public :

 int result;

 void add(int a)
 {
    result=a+a;
    cout<<"Result ="<<result<<endl;
 }
 void add(int b,int c)
 {
    result =b+c;
    cout<<"The Result "<<result<<endl;
 }
};
int main()
{
   ovi s1;
   s1.add(4);
   s1.add(5,6);
}
*/

#include<iostream>
using namespace std;
class ovi{
 public :
 double x,y,z,a,b;

 void triangle(double x,double y)
 {
   z=0.5*x*y;
   cout<<"Area1 ="<<z<<endl;
 }
 void rectangle(double x,double y)
 {
   a=x*y;
   cout<<"Area2 ="<<a<<endl;
 }
 void squre(double x)
 {
   b=x*x;
   cout<<"Area ="<<b<<endl;
 }
};

int main()
{
   ovi ob;
   ob.triangle(45.4,7);
   ob.rectangle(46,67);
   ob.squre(8);
   //int p,q;
   //cin>>p>>q;
   //ob.triangle(p,q);
  // ob.rectangle(p,q);
   //ob.squre(p);
}
