#include<iostream>
using namespace std;

class animal{
    public :
    void info(){
        cout<<"i am animal";
    }
 
};

class dog : public animal{
 public :
 void bark(){
    cout<<"I am a dog. gaw gaw"<<endl;
 }
};

class cat : public animal{
  public :
    void meow(){
        cout<<"I am a cat, meow meow"<<endl;
    }
};

class tiger : public animal{
  public :
   void halum(){
     cout<<" I am a Tiger, halum,halum"<<endl;
   }
};

int main()
{
    dog s1;
    s1.info();
    s1.bark();

     cat s2;
     s2.info();
     s2.meow();

     tiger s3;
     s3.info();
     s3.halum();
}