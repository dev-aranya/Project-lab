#include<bits/stdc++.h>
using namespace std;
class shape{
    public:
    double area(double r){
        double x=r*r;
    }
};
class circle:public shape{
    public:
    
}
int main(){
   
    double a,b;
    cin>>a>>b;
    shape ob,ob1;
}