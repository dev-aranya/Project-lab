#include<bits/stdc++.h>
using namespace std;
int main(){
    deque<int>dq;
    dq.push_back(1);
    dq.push_back(2);
    dq.push_back(3);
    dq.push_back(7);
    //dq.push_front(5);
    // int a=dq.size();
    // cout<<a<<endl;
   // dq.pop_front();
  // dq.pop_back();
    //dq.clear();
    // deque<int>::iterator it,it1;
    // it=dq.begin();
    // it1=dq.begin()+2;
    // dq.erase(it,it1);
    deque<int>::iterator it;
    it=dq.begin()+2;
   // dq.insert(it,8);
   dq.insert(it,3,8);
    for(int i=0;i<dq.size();i++){
        cout<<dq.at(i)<<" ";
    }
    cout<<endl;
    // cout<<dq.front()<<endl;
    //cout<<dq.back()<<endl;
    // if(dq.empty())cout<<"Empty"<<endl;
    // else cout<<"Not Empty"<<endl;
}