/*
#include<iostream>
using namespace std;

class ovi{
 public :
 string name;
 int age;
 void input(){
 cin>>age>>name;
    
 }
};
class student : public ovi{
 public :
  void display()
  {
    
    cout<<"Name ="<<name<<endl;
    cout<<"Age ="<<age<<endl;
    cout<<"Congratulation"<<endl;
  }
};

int main()
{
    student id;
    id.input();
    id.display();
}
*/
#include<iostream>
using namespace std;

class person{
 public :
 string name;
 int age;
 void display()
 {
  cout<<"Thank You"<<endl;
 }

};
class student : public person {
  public :
  void input(){
    cin>>name>>age;
  }
  void display(){
    cout<<" Hello"<<name<<"Age is"<<age<<endl;
  }
};
int main()
{
  student s1;
  s1.input();
  s1.display();
  s1.person :: display();
}