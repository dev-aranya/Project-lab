
#include <bits/stdc++.h>
using namespace std;

class Date {
private:
    int day;
    int month;
    int year;

public:
    Date(int x, int y, int z) : day(x), month(y), year(z) {}
    void setDay(int x) {
        day = x;
    }
    void setMonth(int y) {
        month = y;
    }
    void setYear(int z) {
        year = z;
    }

    int getDay() const {
        return day;
    }

    int getMonth() const {
        return month;
    }
    int getYear() const {
        return year;
    }
    
    bool isValid() const {
        if (year < 0 || month < 1 || month > 12 || day < 1)
            return false;
        int maxDay = 31;
 if (month == 4 || month == 6 || month == 9 || month == 11)
            maxDay = 30;
        else if (month == 2) {
            if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
                maxDay = 29;
            else
                maxDay = 28;
        }
        return (day <= maxDay);
    }
};

int main() {
    int day, month, year;

    cout << "Enter day, month, and year: ";
    cin >> day >> month >> year;
    Date date(day, month, year);

    if (date.isValid()) {
        cout << "Date is valid.\n";
        cout << "Day: " << date.getDay() << ", Month: " << date.getMonth() << ", Year: " << date.getYear() << endl;
    } 
    else {
        cout << "Invalid date entered.\n";
    }
    
return 0;
}