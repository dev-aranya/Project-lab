#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--){
        int n;cin>>n;
        ostringstream str1;
        str1<<n;
        string s=str1.str();//strng numbers
        long long int sum=0;
        int len =s.length();
        for(int i=0;i<len;i++){
            char x=s[i];//50
            int p=x;//50
            p=p-48;//We get digits. //50-48=2
            sum =sum+p;

        }
        cout<<sum<<endl;
    }
}