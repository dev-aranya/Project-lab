/*
#include<bits/stdc++.h>
using namespace std;
class animal{
    //private:
    string name;
    int age;
    public:
    string A;
    int b;
    void setvalue(string x,int y){
        name=x;
        age=y;
    } 
    void getvalue(){
        cout<<"Name="<<name<<endl;
        cout<<"Age="<<age<<endl;
    }
};
int main(){
    string n;
    int m;
    cin>>n>>m;
    animal Zebra;
    Zebra.setvalue(n,m);
    Zebra.getvalue();
    animal Dolphin;
    Dolphin.setvalue(n,m);
    
    Dolphin.getvalue();
}


#include<bits/stdc++.h>
using namespace std;
class Animal {
protected:
    string name;
    int age;
    
public:
    void set_values(string n, int a) {
        name = n;
        age = a;
    }
};

class Zebra : public Animal {
public:
    void display_info() {
        cout << "Zebra Name: " << name << endl;
        cout << "Zebra Age: " << age << endl;
    }
};

class Dolphin : public Animal {
public:
    void display_info() {
        cout << "Dolphin Name: " << name << endl;
        cout << "Dolphin Age: " << age << endl;
    }
};

int main() {
    Zebra zebra;
    zebra.set_values("Stripes", 5);
    zebra.display_info();
    
    cout << endl; // Adding a newline for readability
    
    Dolphin dolphin;
    dolphin.set_values("Flipper", 8);
    dolphin.display_info();
    
    return 0;
}

*/

#include<bits/stdc++.h>
using namespace std;

class animal{
    //private:
    protected:
    string name;
    int age;
    public:
    void set_value(string n,int m){
      name=n;
      age=m;
    }
};
class Zebra:public animal{
    public:
    void display(){
        cout<<"zebra name="<<name<<endl;
        cout<<"Zebra age="<<age<<endl;
    }
};
class Dolphin:public animal{
    public:
    void display1(){
        cout<<"Dolphin name ="<<name<<endl;
        cout<<"doiphin age ="<<age<<endl;
    }
};
int main(){
    Zebra ob;
    ob.set_value("abcd",34);
    ob.display();
    cout<<endl;
    Dolphin ob2;
    ob2.set_value("cefg",76);
    ob2.display1();


}