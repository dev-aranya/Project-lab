#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a=12,b=10;
    int c,d;
    c=a++ + ++b;
    d=++a + b++;
    cout<<c<<endl;
    cout<<d<<endl;
    int e,f;
    e=10,f=11;
    c=--e - --f;
    d=e-- - f--;
    cout<<c<<endl;
    cout<<d<<endl;

}