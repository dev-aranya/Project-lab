// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//     int a=10;
//     int *ptr;
//     ptr=&a;
//     cout<<&a<<endl;
//     cout<<ptr<<endl;
//     cout<<*ptr<<endl;
//     *ptr=39;
//     cout<<*ptr<<endl;
// }


//pointer Arithmetic
// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//     int a=10;
//     int *aptr=&a;
//     cout<<aptr<<endl;
//     aptr++;
//     cout<<aptr<<endl;
// }

// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//     char ch='a';
//     char *cptr;
//     cptr=&ch;
//     cout<<cptr<<endl;
//     cptr++;
//     cout<<cptr<<endl;
// }


//Arry pointer
// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//     int arr[]={10,23,45};
//     cout<<*arr<<endl;
//     int *ptr=arr;
//     for(int i=0;i<3;i++){
//         // cout<<*ptr<<endl;
//         // ptr++;
//         cout<<*(arr+i)<<endl;

//     }
// }

//pointer to pointer
// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//     int a=10;
//     int *p;
//     p=&a;
//     cout<<*p<<endl;
//     int **q=&p;
//     cout<<*q<<endl;
//     cout<<**q<<endl;
// }


// passing pointer to function
// #include<bits/stdc++.h>
// using namespace std;
// void swap(int *a,int *b){
//     int temp=*a;
//     *a=*b;
//     *b=temp;
// }

// int main(){
//     int a=3,b=4;
//     // int *aptr=&a;
//     // int *bptr=&b;

//     // swap(aptr,bptr);
//     swap(&a,&b);
//     cout<<a<<" "<<b<<endl;
// }


#include<bits/stdc++.h>
using namespace std;
void increment(int a){
    a++;
}
int main(){
    int x=2;
    increment(x);
    cout<<x<<endl;
}