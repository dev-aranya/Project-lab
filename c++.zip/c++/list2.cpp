#include<bits/stdc++.h>
using namespace std;
int main(){
    /*
    list<int>li={1,2,8,4,0,7,6,7,};
     list<int>li2={1,9,3,6,0,7,6,7,};
    //list<int>::iterator it;
    //it=li.begin();
    //advance(it,3);
   // li.erase(it);
   /*
   list<int>::iterator it,it2;
   it=li.begin();
   it2=li.begin();
   advance(it2,3);
   li.erase(it,it2);
   
    //li.remove(3);
    //li.reverse();
    //li.sort();
    //li.unique();
    li.swap(li2);
    for(auto it:li){
    cout<<it<<" ";
    }
    cout<<endl;
     for(auto it:li2){
    cout<<it<<" ";
    }
    //cout<<endl;
    */
    
    list<int>li={1,2,3,4,5};
    list<int>li2={6,7,8,9,20};
    li.merge(li2);
    for(auto it:li)cout<<it<<" ";
    cout<<endl;
}