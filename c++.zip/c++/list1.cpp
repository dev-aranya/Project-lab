#include<bits/stdc++.h>
using namespace std;
int main(){
    // list<int>li;
    // li.push_back(2);
    // li.push_back(3);
    // li.push_back(7);
    // li.push_front(1);

    // list<int>::iterator it;
    // for(it=li.begin();it!=li.end();it++){
    //     cout<<*it<<" ";
    // }
    //li.pop_front();
    //li.pop_back();
    // for(auto it:li){
    //     cout<<it<<" ";
    // }
    // cout<<endl;
    // cout<<li.front()<<endl;
    // cout<<li.back()<<endl;
     //cout<<li.size()<<endl;
    //  li.clear();
    //  for(auto it:li){
    //     cout<<it<<" ";
    //  }
    //  if(li.empty())cout<<"Empty"<<endl;
    //  else cout<<"Not Empty"<<endl;
    
    // li.insert(li.begin(),5);
    // for(auto it:li){
    //     cout<<it<<" ";
    // }
    // cout<<endl;

    list<int>li={1,2,2,2,3,4,2,9,5,6};
    list<int>li1={2,3,4,5,6,7,8};
    //list<int>:: iterator it;
    // it=li.begin();
    //  advance(it,3);
    // li.erase(it);
    //li.remove(2);
    //li.reverse();
    //li.sort();
    //li.unique();
    //li.swap(li1);
    li.merge(li1);
    for(auto it:li)
    {
        cout<<it<<" ";
    }
    cout<<endl;
    //for(auto it:li1)cout<<it<<" ";
   // cout<<endl;

}//