#include<bits/stdc++.h>
using namespace std;
int main(){
    char letter;
     cout<<"Enter letter=";
    cin>>letter;
   
    switch(letter)
    {
        case 'a':
        cout<<"hii"<<endl;
        break;
         case 'b':
        cout<<"hello"<<endl;
        break;
         case 'c':
        cout<<"god"<<endl;
        break;
         case 'd':
        cout<<"Good"<<endl;
        break;
        default :
        cout<<"Bad"<<endl;
        break;
    }
}