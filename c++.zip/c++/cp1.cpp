
// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//   int marks;
//   cin>>marks;

//   string result= (marks>=40)? "Pass":"Fail";
//    cout<<result;
// }


#include<bits/stdc++.h>
using namespace std;
int main(){
  int t;
  cin>>t;
  while((t--)>0){
    int n;
    cin>>n;
    cout<<(n-1)<<endl;
  }
}