// #include<bits/stdc++.h>
// using namespace std;
// void increment(int &n,int n1){
//     n++;
//     n1++;
// }
// int main()
// {
//     int a=4;
//     int b=5;
//     cout<<a<<" "<<b<<endl;
//     increment(a,b);
//     cout<<a<<" "<<b<<endl;

// }


// #include<bits/stdc++.h>
// using namespace std;
// void swap(int &a,int &b){
//     int temp=a;
//     a=b;
//     b=temp;
// }
// int main(){
//     int a=3;
//     int b=5;
//     cout<<a<<" "<<b<<endl;
//     swap(a,b);
//     cout<<a<<" "<<b<<endl;
// }



// #include<bits/stdc++.h>
// using namespace std;
// int main(){
//     int x=4;
//     int *p_x=&x;
//     cout<<"Address x: "<<&x<<endl;
//     cout<<" value p_x: "<<p_x<<endl;
//     cout<<"value *p_x:"<<*p_x<<endl;
//     *p_x=5;
//     cout<<"x: "<<x<<endl;
//     cout<<"p_x +1: "<<p_x+1<<endl;
//     int **p_p_x=&p_x;
//      cout<<"Address p_x: "<<&p_x<<endl;
//     cout<<" value p_p_x: "<<p_p_x<<endl;
//     cout<<"value *p_p_x:"<<*p_p_x<<endl;
//     cout<<"value **p_p_x:"<<**p_p_x<<endl;
//     **p_p_x=7;
//     cout<<"x: "<<x<<endl;
// }


#include<bits/stdc++.h>
using namespace std;
void increment(int *x){
    *x=*x+2;
}
int main(){
    int a=4;
    cout<<a<<endl;
    increment(&a);
    cout<<a<<endl;
}