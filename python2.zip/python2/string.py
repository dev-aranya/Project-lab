# name="Aranya DEbnath"
# a=name[0:5]
# print(a)
# b=name[3]
# print(b)
# print(name[-8:-1])
# print(name[1:8])
# print(name[0:5])
# print(name[2:8])

#slicing with skip value
word = "amazon_google"
print(word[1:8])
print(word[1:12:3])