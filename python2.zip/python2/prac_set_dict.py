# words={
#     "madad":"help",
#     "kursi":"chair",
#     "billi":"cat"
# }
# word=input("enter the word  you want meaning = ")
# print(words[word])

# s=set()
# n=input("Enter number : ")
# s.add(int(n))
# n=input("Enter number : ")
# s.add(int(n))
# n=input("Enter number : ")
# s.add(int(n))
# n=input("Enter number : ")
# s.add(int(n))
# n=input("Enter number : ")
# s.add(int(n))
# n=input("Enter number : ")
# s.add(int(n))
# n=input("Enter number : ")
# s.add(int(n))

# print(s)

# a=set()
# a.add(23)
# a.add("23")
# print(a)

# a=set()
# a.add(23)
# a.add(23.0)
# a.add("23")
# print(a)
# print(len(a))

# s={}
# print(type(s))

d={}

name=input("Enter the name :")
language=input("Enter the language name: ")
d.update({name:language})
name=input("Enter the name :")
language=input("Enter the language name: ")
d.update({name:language})
name=input("Enter the name :")
language=input("Enter the language name: ")
d.update({name:language})
name=input("Enter the name :")
language=input("Enter the language name: ")
d.update({name:language})
name=input("Enter the name :")
language=input("Enter the language name: ")
d.update({name:language})
name=input("Enter the name :")
language=input("Enter the language name: ")
d.update({name:language})

print(d)