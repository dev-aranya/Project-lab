# s={3,4,7,8,9,5}
# print(s)
# print(type(s))
# s.add(67)
# print(s)
# print(len(s))
# s.remove(7)
# print(s)

s1={3,4,5,6,7,8}
s2={5,6,7,3,2}
x=s1.union(s2)
print(x)
y=s1.intersection(s2)
print(y)