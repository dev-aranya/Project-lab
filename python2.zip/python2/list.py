friends=["dip","gourob",'sajid',"soumik",6,False,"azim","sadi"]
print(friends[1])
friends[0]="Piyal"
# print(friends[0])
# print(friends[1:5])
# print(friends)
# friends.append("nayem")
# print(friends)
li1=[2,4,1,34,6,79,9]
# li1.sort()
# li1.reverse()
# li1.insert(2,90)
li1.pop(4)
print(li1)