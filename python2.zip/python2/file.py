f=open("file.txt","read")
data=f.read()
print(data)
f.close()