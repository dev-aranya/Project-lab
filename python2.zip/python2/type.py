a="OVI"
b=type(a)
print(b)