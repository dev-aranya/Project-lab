#add 2 number 
a=2
b=3
c=a+b
print(c)

#Reminder
x=34
y=5
print("Reminder = ",x%y)

#squre 
a=int(input("Enter the number = "))
print("Squre number= ",a**2)