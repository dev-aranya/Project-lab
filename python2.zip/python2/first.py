# a=1
# b=2

# print(a+b)
# b= 5>=5
# print (b)
# print(not(True))
a= int(input("enter number 1 "))
b= int(input("input num 2 "))

print("number 1 = ",a)
print("number 1 = ",b)
print("sum = ",a+b)