a=34
def fun():
    a=6
    print(a)

print(a)
fun()    