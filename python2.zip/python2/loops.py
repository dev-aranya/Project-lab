# for i in range(1,6):
#     print(i)

# i=1
# while(i<51):
#     print(i)
#     i+=1    


#For looplist
# li=[1,"ert",56,"itu","kjh"]
# i=0
# while(i<len(li)):
#     print(li[i])
#     i+=1

#for loop
# for i in range(0,100,5):
#     print(i)

#for loop list
# li=[1,23,67,98]
# for i in li:
#     print(i)

#for loop tuple
# t=(2,3,45,6,7)
# for i in t:
#     print(i)

#for loop string
# name="Aranya"
# for i in name:
#     print(i)


# l=[1,2,34,5]
# for item in l:
#     print(item)
# else :
#     print("Done")    

#break_statement
# for i in range(1,80):
#     print(i)
#     if(i==12):
#         break
for i in range(1,80):
    print(i)
    if(i==12):
        continue
    print(i)



