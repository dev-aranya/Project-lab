str="hey ovi you are amazing"
f=open("myfile.txt","w")
f.write(str)
f.close()