# a=["mango","jackfruit","orange","banana","apple","black_berry","licci"]
# print(a)

# fruits=[]

# f1=input("Enter fruit name : ")
# fruits.append(f1)
# f2=input("Enter fruit name : ")
# fruits.append(f2)
# f3=input("Enter fruit name : ")
# fruits.append(f3)
# f4=input("Enter fruit name : ")
# fruits.append(f4)
# f5=input("Enter fruit name : ")
# fruits.append(f5)
# f6=input("Enter fruit name : ")
# fruits.append(f6)
# f7=input("Enter fruit name : ")
# fruits.append(f7)

# print(fruits)

# marks=[]

# f1=int(input("Enter marks here: "))
# marks.append(f1)
# f2=int(input("Entermarks here : "))
# marks.append(f2)
# f3=int(input("Entermarks here : "))
# marks.append(f3)
# f4=int(input("Entermarks here : "))
# marks.append(f4)
# f5=int(input("Entermarks here : "))
# marks.append(f5)
# f6=int(input("Entermarks here : "))
# marks.append(f6)
# f7=int(input("Entermarks here : "))
# marks.append(f7)

# marks.sort()
# print(marks)

# li=[3,4,567,78]
# print("sum = ",sum(li))

x=(7,0,9,0,0,0,8)
a=x.count(0)
print(a)