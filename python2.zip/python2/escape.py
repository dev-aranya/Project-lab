a="ovi is a good boy\n but not a bad\n \"boy\""
print(a)