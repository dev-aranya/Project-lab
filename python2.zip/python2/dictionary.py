marks={
    "ovi":87,
    "deb":78,
    "nath":88
}
# print(marks)
# print(type(marks))
# print(marks["ovi"])

# print(marks.items())
# print(marks.keys())
# print(marks.values())
# marks.update({"ovi":99,"aranya":90})
# print(marks)
print(marks.get("ovi"))
print(marks["ovi"])