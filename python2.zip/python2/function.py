name="Aranya"
a="debnath"
print(len(name))
# print(name.endswith("ya"))
# print(name.endswith("yaa"))
# print(name.startswith("Ar"))
# print(name.startswith("Arr"))
# print(a.capitalize())

s="debnath ovi"
# index=s.find('ovi')
# print(index)
#replace
b=s.replace("ovi","aranya")
print(b)